import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  console.error('Missing Supabase environment variables');
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true
  }
});

// Helper function to check if a user is authenticated
export const isAuthenticated = async () => {
  try {
    const { data, error } = await supabase.auth.getSession();
    if (error) return false;
    return !!data.session;
  } catch (err) {
    console.error('Auth check error:', err);
    return false;
  }
};

// Helper function to safely handle Supabase errors
export const handleSupabaseError = (error: any): string => {
  if (!error) return 'An unknown error occurred';
  
  console.error('Supabase error details:', error);
  
  // Extract the message from various error formats
  let message = '';
  if (typeof error === 'string') {
    message = error;
  } else if (error.message) {
    message = error.message;
  } else if (error.error_description) {
    message = error.error_description;
  } else if (error.details) {
    message = error.details;
  }
  
  // Map common error messages to user-friendly versions
  if (message.includes('invalid_credentials') || message.includes('Invalid login credentials')) {
    return 'Invalid email or password. Please try again.';
  } else if (message.includes('rate limit')) {
    return 'Too many attempts. Please try again later.';
  } else if (message.includes('already registered')) {
    return 'This email is already registered. Please use a different email or try logging in.';
  } else if (message.includes('weak password')) {
    return 'Please use a stronger password.';
  }
  
  // Return the original message if no mapping exists
  return message || 'An error occurred. Please try again.';
};