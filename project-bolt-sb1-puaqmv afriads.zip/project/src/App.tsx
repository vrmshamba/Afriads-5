import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Features from './components/Features';
import About from './components/About';
import Pricing from './components/Pricing';
import FAQ from './components/FAQ';
import Contact from './components/Contact';
import LoginPage from './components/auth/LoginPage';
import Dashboard from './components/Dashboard';
import RegisterForm from './components/auth/RegisterForm';
import AuthCallback from './components/auth/AuthCallback';
import MediaInventory from './components/MediaInventory';
import ForgotPassword from './components/auth/ForgotPassword';
import ResetPassword from './components/auth/ResetPassword';
import TermsAndConditions from './components/legal/TermsAndConditions';
import TelegramAds from './components/advertising/TelegramAds';
import MobileGameAds from './components/advertising/MobileGameAds';
import MediaPlanning from './components/MediaPlanning';
import AnalyticsDashboard from './components/analytics/AnalyticsDashboard';
import CampaignDetails from './components/analytics/CampaignDetails';
import AudienceInsights from './components/analytics/AudienceInsights';
import PredictiveAnalytics from './components/analytics/PredictiveAnalytics';
import CompetitorBenchmark from './components/analytics/CompetitorBenchmark';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/register" element={<RegisterForm />} />
          <Route path="/auth/callback" element={<AuthCallback />} />
          <Route path="/auth/forgot-password" element={<ForgotPassword />} />
          <Route path="/auth/reset-password" element={<ResetPassword />} />
          <Route path="/media-inventory" element={<MediaInventory />} />
          <Route path="/media-planning" element={<MediaPlanning />} />
          <Route path="/terms" element={<TermsAndConditions />} />
          <Route path="/advertising/telegram" element={<TelegramAds />} />
          <Route path="/advertising/mobile-games" element={<MobileGameAds />} />
          <Route path="/analytics" element={<AnalyticsDashboard />} />
          <Route path="/analytics/campaign/:id" element={<CampaignDetails />} />
          <Route path="/analytics/audience" element={<AudienceInsights />} />
          <Route path="/analytics/predictive" element={<PredictiveAnalytics />} />
          <Route path="/analytics/benchmark" element={<CompetitorBenchmark />} />
          <Route path="/" element={
            <>
              <Hero />
              <Features />
              <About />
              <Pricing />
              <FAQ />
              <Contact />
            </>
          } />
        </Routes>
      </div>
    </Router>
  );
}

export default App;