import React from 'react';
import { Link } from 'react-router-dom';
import { Shield } from 'lucide-react';

export default function TermsAndConditions() {
  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <Shield className="mx-auto h-12 w-12 text-orange-600" />
          <h1 className="mt-2 text-3xl font-extrabold text-gray-900 sm:text-4xl">
            Terms and Conditions
          </h1>
          <p className="mt-4 text-lg text-gray-500">
            Last updated: February 24, 2025
          </p>
        </div>

        <div className="mt-12 prose prose-orange mx-auto">
          <h2>1. Introduction</h2>
          <p>
            Welcome to AfriAds. By accessing our website and using our services, you agree to these terms and conditions.
            These terms constitute a legally binding agreement between you and AfriAds regarding your use of our advertising platform.
          </p>

          <h2>2. GDPR Compliance</h2>
          <p>
            We are committed to protecting your personal data and complying with the General Data Protection Regulation (GDPR).
            As a data controller, we process personal data according to the following principles:
          </p>
          <ul>
            <li>Lawfulness, fairness, and transparency</li>
            <li>Purpose limitation</li>
            <li>Data minimization</li>
            <li>Accuracy</li>
            <li>Storage limitation</li>
            <li>Integrity and confidentiality</li>
            <li>Accountability</li>
          </ul>

          <h2>3. Your Rights Under GDPR</h2>
          <p>
            Under GDPR, you have the following rights:
          </p>
          <ul>
            <li>The right to be informed</li>
            <li>The right of access</li>
            <li>The right to rectification</li>
            <li>The right to erasure</li>
            <li>The right to restrict processing</li>
            <li>The right to data portability</li>
            <li>The right to object</li>
            <li>Rights related to automated decision-making and profiling</li>
          </ul>

          <h2>4. Data Collection and Use</h2>
          <p>
            We collect and process personal data for the following purposes:
          </p>
          <ul>
            <li>Account creation and management</li>
            <li>Advertising campaign management</li>
            <li>Analytics and performance tracking</li>
            <li>Communication and support</li>
            <li>Legal compliance</li>
          </ul>

          <h2>5. Cookie Policy</h2>
          <p>
            We use cookies and similar technologies to improve your experience on our platform.
            You can control cookie preferences through your browser settings.
          </p>

          <h2>6. Third-Party Services</h2>
          <p>
            Our platform integrates with third-party services for payment processing, analytics, and advertising delivery.
            These services have their own privacy policies and terms of service.
          </p>

          <h2>7. Data Security</h2>
          <p>
            We implement appropriate technical and organizational measures to ensure the security of your personal data,
            including encryption, access controls, and regular security assessments.
          </p>

          <h2>8. Contact Information</h2>
          <p>
            For any questions about these terms or your personal data, contact our Data Protection Officer at:
            <br />
            Email: dpo@afriads.com
            <br />
            Address: Lagos, Nigeria
          </p>

          <div className="mt-8 border-t border-gray-200 pt-8">
            <p className="text-sm text-gray-500">
              By using AfriAds, you acknowledge that you have read and understood these terms and conditions
              and agree to be bound by them.
            </p>
          </div>
        </div>

        <div className="mt-8 text-center">
          <Link
            to="/"
            className="text-orange-600 hover:text-orange-500"
          >
            Return to Home
          </Link>
        </div>
      </div>
    </div>
  );
}