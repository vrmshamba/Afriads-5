import React, { useState } from 'react';
import { 
  Target, 
  Users, 
  TrendingUp, 
  DollarSign, 
  BarChart3, 
  Radio, 
  Smartphone, 
  MessageCircle,
  ChevronDown,
  ChevronUp,
  CalendarPlus,
  Tv,
  Globe2
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface MediaPlan {
  budget: string;
  objective: string;
  audience: string;
  region: string;
}

interface MediaRecommendation {
  platform: string;
  percentage: number;
  reason: string;
  estimatedReach: string;
  suggestedContent: string;
  icon: React.ElementType;
  route: string;
}

export default function MediaPlanning() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState<MediaPlan>({
    budget: '',
    objective: '',
    audience: '',
    region: ''
  });

  const [recommendations, setRecommendations] = useState<MediaRecommendation[]>([]);
  const [showRecommendations, setShowRecommendations] = useState(false);
  const [expandedPlatform, setExpandedPlatform] = useState<string | null>(null);

  const objectives = [
    'Brand Awareness',
    'Lead Generation',
    'Sales Conversion',
    'App Downloads',
    'Community Engagement'
  ];

  const audiences = [
    'Youth (18-24)',
    'Young Professionals (25-34)',
    'Middle-aged Adults (35-44)',
    'Senior Professionals (45+)',
    'All Age Groups'
  ];

  const regions = [
    'East Africa',
    'West Africa',
    'Southern Africa',
    'North Africa',
    'Pan-African'
  ];

  const generateRecommendations = (data: MediaPlan): MediaRecommendation[] => {
    const recommendations: MediaRecommendation[] = [];
    const budget = parseFloat(data.budget);
    
    if (data.objective === 'Brand Awareness') {
      recommendations.push({
        platform: 'Telegram Channels',
        percentage: 40,
        reason: 'High user engagement and viral potential',
        estimatedReach: '2M+ users',
        suggestedContent: 'Visual storytelling content with local cultural elements',
        icon: MessageCircle,
        route: '/advertising/telegram'
      });
      recommendations.push({
        platform: 'Mobile Games',
        percentage: 35,
        reason: 'Captive audience with high attention span',
        estimatedReach: '1.5M+ gamers',
        suggestedContent: 'Interactive ads with brand messaging',
        icon: Smartphone,
        route: '/advertising/mobile-games'
      });
      recommendations.push({
        platform: 'Broadcast Media',
        percentage: 25,
        reason: 'Wide reach across demographics',
        estimatedReach: '3M+ audience',
        suggestedContent: 'Memorable content across TV and radio',
        icon: Radio,
        route: '/media-inventory'
      });
    } else if (data.objective === 'Sales Conversion') {
      recommendations.push({
        platform: 'Mobile Games',
        percentage: 45,
        reason: 'High conversion rates through rewarded ads',
        estimatedReach: '1M+ active users',
        suggestedContent: 'Product showcase with special offers',
        icon: Smartphone,
        route: '/advertising/mobile-games'
      });
      recommendations.push({
        platform: 'Telegram Channels',
        percentage: 35,
        reason: 'Direct response capabilities',
        estimatedReach: '1.5M+ users',
        suggestedContent: 'Limited-time offers with clear CTAs',
        icon: MessageCircle,
        route: '/advertising/telegram'
      });
      recommendations.push({
        platform: 'Broadcast Media',
        percentage: 20,
        reason: 'Brand credibility building',
        estimatedReach: '5M+ viewers',
        suggestedContent: 'Product demonstrations with testimonials',
        icon: Tv,
        route: '/media-inventory'
      });
    } else {
      recommendations.push({
        platform: 'Integrated Media Mix',
        percentage: 100,
        reason: 'Balanced approach for optimal results',
        estimatedReach: '5M+ audience',
        suggestedContent: 'Coordinated campaign across all platforms',
        icon: Globe2,
        route: '/media-inventory'
      });
    }

    // Adjust recommendations based on region
    if (data.region === 'East Africa') {
      recommendations.forEach(rec => {
        if (rec.platform === 'Telegram Channels') {
          rec.estimatedReach = '1.8M+ users in Kenya, Uganda, Tanzania';
          rec.suggestedContent += ' with Swahili language options';
        }
      });
    } else if (data.region === 'West Africa') {
      recommendations.forEach(rec => {
        if (rec.platform === 'Mobile Games') {
          rec.estimatedReach = '2.5M+ users in Nigeria, Ghana';
          rec.percentage += 5;
        }
      });
    }

    return recommendations;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.budget || !formData.objective || !formData.audience || !formData.region) {
      return;
    }
    const newRecommendations = generateRecommendations(formData);
    setRecommendations(newRecommendations);
    setShowRecommendations(true);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleBookPlatform = (route: string) => {
    navigate(route);
  };

  const togglePlatform = (platform: string) => {
    setExpandedPlatform(expandedPlatform === platform ? null : platform);
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-gray-900">Media Planning Assistant</h1>
          <p className="mt-2 text-lg text-gray-600">
            Get personalized recommendations for your media mix
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Campaign Parameters</h2>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Campaign Budget (USD)
                </label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <DollarSign className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="number"
                    name="budget"
                    value={formData.budget}
                    onChange={handleInputChange}
                    className="focus:ring-orange-500 focus:border-orange-500 block w-full pl-10 pr-12 sm:text-sm border-gray-300 rounded-md"
                    placeholder="Enter your budget"
                    min="100"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Campaign Objective
                </label>
                <select
                  name="objective"
                  value={formData.objective}
                  onChange={handleInputChange}
                  className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-orange-500 focus:border-orange-500 sm:text-sm rounded-md"
                  required
                >
                  <option value="">Select an objective</option>
                  {objectives.map(objective => (
                    <option key={objective} value={objective}>{objective}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Target Audience
                </label>
                <select
                  name="audience"
                  value={formData.audience}
                  onChange={handleInputChange}
                  className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-orange-500 focus:border-orange-500 sm:text-sm rounded-md"
                  required
                >
                  <option value="">Select target audience</option>
                  {audiences.map(audience => (
                    <option key={audience} value={audience}>{audience}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Target Region
                </label>
                <select
                  name="region"
                  value={formData.region}
                  onChange={handleInputChange}
                  className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-orange-500 focus:border-orange-500 sm:text-sm rounded-md"
                  required
                >
                  <option value="">Select region</option>
                  {regions.map(region => (
                    <option key={region} value={region}>{region}</option>
                  ))}
                </select>
              </div>

              <button
                type="submit"
                className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-orange-600 hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500"
              >
                Generate Recommendations
              </button>
            </form>
          </div>

          <div className="bg-black rounded-lg shadow-lg p-6">
            <h2 className="text-xl font-semibold text-white mb-6">Recommended Media Mix</h2>
            {showRecommendations ? (
              <div className="space-y-4">
                {recommendations.map((rec, index) => (
                  <div key={index} className="border border-gray-800 rounded-lg overflow-hidden bg-gray-900">
                    <div 
                      className="bg-gray-800 p-4 cursor-pointer hover:bg-gray-700 transition-colors"
                      onClick={() => togglePlatform(rec.platform)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <rec.icon className="h-6 w-6 text-orange-500" />
                          <h3 className="text-lg font-medium text-white">{rec.platform}</h3>
                        </div>
                        <div className="flex items-center space-x-4">
                          <span className="text-orange-500 font-semibold">{rec.percentage}%</span>
                          {expandedPlatform === rec.platform ? (
                            <ChevronUp className="h-5 w-5 text-gray-400" />
                          ) : (
                            <ChevronDown className="h-5 w-5 text-gray-400" />
                          )}
                        </div>
                      </div>
                      <div className="mt-2 w-full bg-gray-700 rounded-full h-1.5">
                        <div 
                          className="bg-orange-500 h-1.5 rounded-full" 
                          style={{ width: `${rec.percentage}%` }}
                        ></div>
                      </div>
                    </div>
                    
                    {expandedPlatform === rec.platform && (
                      <div className="p-4 border-t border-gray-800">
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <p className="font-medium text-gray-300">Estimated Reach</p>
                            <p className="text-gray-400">{rec.estimatedReach}</p>
                          </div>
                          <div>
                            <p className="font-medium text-gray-300">Best For</p>
                            <p className="text-gray-400">{rec.reason}</p>
                          </div>
                        </div>
                        <button
                          onClick={() => handleBookPlatform(rec.route)}
                          className="mt-4 w-full flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-black bg-orange-500 hover:bg-orange-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-orange-500 transition-colors"
                        >
                          <CalendarPlus className="w-4 h-4 mr-2" />
                          Book {rec.platform}
                        </button>
                      </div>
                    )}
                  </div>
                ))}

                <div className="mt-6 p-4 bg-gray-800 rounded-lg border border-gray-700">
                  <h3 className="text-lg font-medium text-orange-500 mb-2">Quick Tips</h3>
                  <ul className="text-sm text-gray-300 space-y-1">
                    <li>• Click each platform for detailed information</li>
                    <li>• Book individual platforms or mix services</li>
                    <li>• Adjust your parameters to see different recommendations</li>
                  </ul>
                </div>
              </div>
            ) : (
              <div className="text-center text-gray-400 py-12">
                <BarChart3 className="mx-auto h-12 w-12 mb-4" />
                <p>Fill out the form to get personalized recommendations</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}