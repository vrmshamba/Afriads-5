import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  BarChart3, 
  PieChart, 
  TrendingUp, 
  Users, 
  Target, 
  Calendar, 
  ArrowRight, 
  Lightbulb,
  Zap,
  RefreshCw
} from 'lucide-react';
import { supabase } from '../../lib/supabase';
import PerformanceOverview from './PerformanceOverview';
import CampaignList from './CampaignList';
import RecentActivity from './RecentActivity';
import AIRecommendations from './AIRecommendations';

export default function AnalyticsDashboard() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [user, setUser] = useState<any>(null);
  const [dashboardData, setDashboardData] = useState<any>({
    campaigns: [],
    performance: {
      impressions: 0,
      clicks: 0,
      conversions: 0,
      ctr: 0,
      conversionRate: 0,
      spend: 0,
      roi: 0
    },
    recentActivity: [],
    recommendations: []
  });
  const [dateRange, setDateRange] = useState('7d');
  const [isRefreshing, setIsRefreshing] = useState(false);

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const { data: { user }, error } = await supabase.auth.getUser();
        if (error || !user) {
          navigate('/login');
          return;
        }
        setUser(user);
        fetchDashboardData();
      } catch (err) {
        console.error('Auth check error:', err);
        navigate('/login');
      }
    };

    checkAuth();
  }, [navigate]);

  const fetchDashboardData = async () => {
    setIsLoading(true);
    try {
      // In a real app, this would fetch from your API
      // For demo purposes, we'll use mock data
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const mockCampaigns = [
        {
          id: 'c1',
          name: 'Summer Promotion',
          status: 'active',
          platform: 'Telegram',
          impressions: 125000,
          clicks: 3750,
          conversions: 450,
          spend: 1200,
          startDate: '2025-01-15',
          endDate: '2025-02-15'
        },
        {
          id: 'c2',
          name: 'App Install Campaign',
          status: 'active',
          platform: 'Mobile Games',
          impressions: 85000,
          clicks: 12500,
          conversions: 3200,
          spend: 2500,
          startDate: '2025-01-20',
          endDate: '2025-03-20'
        },
        {
          id: 'c3',
          name: 'Brand Awareness',
          status: 'completed',
          platform: 'Telegram & Mobile Games',
          impressions: 250000,
          clicks: 7500,
          conversions: 900,
          spend: 3000,
          startDate: '2024-12-01',
          endDate: '2025-01-15'
        }
      ];
      
      const totalImpressions = mockCampaigns.reduce((sum, campaign) => sum + campaign.impressions, 0);
      const totalClicks = mockCampaigns.reduce((sum, campaign) => sum + campaign.clicks, 0);
      const totalConversions = mockCampaigns.reduce((sum, campaign) => sum + campaign.conversions, 0);
      const totalSpend = mockCampaigns.reduce((sum, campaign) => sum + campaign.spend, 0);
      
      const mockPerformance = {
        impressions: totalImpressions,
        clicks: totalClicks,
        conversions: totalConversions,
        ctr: totalImpressions > 0 ? (totalClicks / totalImpressions) * 100 : 0,
        conversionRate: totalClicks > 0 ? (totalConversions / totalClicks) * 100 : 0,
        spend: totalSpend,
        roi: 320 // Calculated ROI percentage
      };
      
      const mockRecentActivity = [
        { id: 'a1', type: 'campaign_created', campaign: 'Summer Promotion', timestamp: '2025-02-10T09:30:00Z' },
        { id: 'a2', type: 'budget_increased', campaign: 'App Install Campaign', amount: 500, timestamp: '2025-02-09T14:15:00Z' },
        { id: 'a3', type: 'campaign_completed', campaign: 'Brand Awareness', timestamp: '2025-01-15T23:59:59Z' },
        { id: 'a4', type: 'creative_updated', campaign: 'Summer Promotion', timestamp: '2025-02-08T11:45:00Z' }
      ];
      
      const mockRecommendations = [
        { 
          id: 'r1', 
          type: 'optimization', 
          title: 'Increase budget for App Install Campaign', 
          description: 'This campaign is performing 35% above average. Increasing budget could yield higher returns.',
          impact: 'high',
          confidence: 85
        },
        { 
          id: 'r2', 
          type: 'targeting', 
          title: 'Refine audience targeting for Summer Promotion', 
          description: 'Adding "Technology Enthusiasts" interest group could improve CTR by approximately 12%.',
          impact: 'medium',
          confidence: 72
        },
        { 
          id: 'r3', 
          type: 'creative', 
          title: 'Update ad creative for Summer Promotion', 
          description: 'A/B testing shows version B performs 18% better. Consider updating all creatives.',
          impact: 'medium',
          confidence: 68
        }
      ];
      
      setDashboardData({
        campaigns: mockCampaigns,
        performance: mockPerformance,
        recentActivity: mockRecentActivity,
        recommendations: mockRecommendations
      });
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await fetchDashboardData();
    setIsRefreshing(false);
  };

  const handleDateRangeChange = (range: string) => {
    setDateRange(range);
    // In a real app, this would refetch data with the new date range
  };

  if (isLoading) {
    return (
      <div className="min-h-screen pt-16 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading your analytics dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Analytics Dashboard</h1>
            <p className="text-gray-600">Track, analyze, and optimize your advertising campaigns</p>
          </div>
          
          <div className="mt-4 md:mt-0 flex items-center space-x-4">
            <div className="flex items-center space-x-2 bg-white rounded-md shadow-sm p-1">
              {['7d', '30d', '90d', 'ytd', 'all'].map((range) => (
                <button
                  key={range}
                  onClick={() => handleDateRangeChange(range)}
                  className={`px-3 py-1 text-sm rounded-md ${
                    dateRange === range 
                      ? 'bg-orange-600 text-white' 
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  {range === '7d' ? 'Week' : 
                   range === '30d' ? 'Month' : 
                   range === '90d' ? 'Quarter' : 
                   range === 'ytd' ? 'Year' : 'All Time'}
                </button>
              ))}
            </div>
            
            <button 
              onClick={handleRefresh}
              disabled={isRefreshing}
              className="flex items-center px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm text-sm text-gray-700 hover:bg-gray-50 disabled:opacity-50"
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
              Refresh
            </button>
          </div>
        </div>

        {/* Performance Overview */}
        <PerformanceOverview performance={dashboardData.performance} />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-8">
          {/* Active Campaigns */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
                <h2 className="text-lg font-medium text-gray-900">Active Campaigns</h2>
                <button 
                  onClick={() => navigate('/analytics/campaign/new')}
                  className="text-sm text-orange-600 hover:text-orange-500 flex items-center"
                >
                  View All
                  <ArrowRight className="h-4 w-4 ml-1" />
                </button>
              </div>
              <div className="p-6">
                <CampaignList campaigns={dashboardData.campaigns} />
              </div>
            </div>
          </div>

          {/* AI Recommendations */}
          <div>
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200 flex items-center">
                <Lightbulb className="h-5 w-5 text-orange-600 mr-2" />
                <h2 className="text-lg font-medium text-gray-900">AI Recommendations</h2>
              </div>
              <div className="p-6">
                <AIRecommendations recommendations={dashboardData.recommendations} />
              </div>
            </div>
          </div>
        </div>

        {/* Quick Links */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
          {[
            { 
              title: 'Audience Insights', 
              icon: Users, 
              description: 'Analyze your audience demographics and behavior',
              path: '/analytics/audience',
              color: 'bg-blue-500'
            },
            { 
              title: 'Predictive Analytics', 
              icon: TrendingUp, 
              description: 'Forecast campaign performance with AI',
              path: '/analytics/predictive',
              color: 'bg-purple-500'
            },
            { 
              title: 'Competitor Benchmark', 
              icon: Target, 
              description: 'Compare your performance against industry standards',
              path: '/analytics/benchmark',
              color: 'bg-green-500'
            },
            { 
              title: 'Campaign Calendar', 
              icon: Calendar, 
              description: 'View and plan your campaign schedule',
              path: '/media-planning',
              color: 'bg-orange-500'
            }
          ].map((item, index) => (
            <div 
              key={index}
              onClick={() => navigate(item.path)}
              className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow cursor-pointer"
            >
              <div className="p-6">
                <div className={`w-12 h-12 rounded-lg ${item.color} flex items-center justify-center mb-4`}>
                  <item.icon className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">{item.title}</h3>
                <p className="text-gray-600 text-sm">{item.description}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Recent Activity */}
        <div className="mt-8">
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200">
              <h2 className="text-lg font-medium text-gray-900">Recent Activity</h2>
            </div>
            <div className="p-6">
              <RecentActivity activities={dashboardData.recentActivity} />
            </div>
          </div>
        </div>

        {/* AI Insights Banner */}
        <div className="mt-8 bg-gradient-to-r from-purple-600 to-indigo-600 rounded-lg shadow-md overflow-hidden">
          <div className="p-6 sm:p-8 flex flex-col sm:flex-row items-center">
            <div className="flex-shrink-0 mb-4 sm:mb-0 sm:mr-6">
              <div className="bg-white/20 rounded-full p-4">
                <Zap className="h-8 w-8 text-white" />
              </div>
            </div>
            <div className="flex-1 text-center sm:text-left">
              <h3 className="text-xl font-bold text-white mb-2">AI-Powered Campaign Optimization</h3>
              <p className="text-white/80 mb-4">Our AI has analyzed your campaigns and found 3 opportunities to improve performance by up to 35%.</p>
              <button 
                onClick={() => navigate('/analytics/predictive')}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-indigo-600 bg-white hover:bg-indigo-50"
              >
                View AI Insights
                <ArrowRight className="ml-2 h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}