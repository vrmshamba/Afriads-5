import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  BarChart3, 
  Calendar, 
  Clock, 
  DollarSign, 
  Edit, 
  Eye, 
  MousePointer, 
  Pause, 
  Play, 
  ShoppingCart, 
  Trash2, 
  TrendingUp,
  Users,
  Share2
} from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, BarChart, Bar, Legend } from 'recharts';

interface CampaignData {
  id: string;
  name: string;
  status: string;
  platform: string;
  impressions: number;
  clicks: number;
  conversions: number;
  spend: number;
  startDate: string;
  endDate: string;
  description?: string;
  objective?: string;
  audience?: {
    countries: string[];
    ageRange: { min: number; max: number };
    gender: string;
    interests: string[];
  };
  creatives?: {
    id: string;
    type: string;
    url: string;
    title: string;
    description: string;
  }[];
}

// Sample data for the charts
const generateDailyData = (days: number, trend: 'up' | 'down' | 'stable' = 'up') => {
  const result = [];
  let baseImpressions = 5000;
  let baseClicks = 200;
  let baseConversions = 25;
  
  for (let i = 0; i < days; i++) {
    const date = new Date();
    date.setDate(date.getDate() - (days - i - 1));
    
    // Add some randomness and trend
    const trendFactor = trend === 'up' ? 1.05 : trend === 'down' ? 0.95 : 1;
    const randomFactor = 0.8 + Math.random() * 0.4; // 0.8 to 1.2
    
    baseImpressions = Math.floor(baseImpressions * trendFactor * randomFactor);
    baseClicks = Math.floor(baseClicks * trendFactor * randomFactor);
    baseConversions = Math.floor(baseConversions * trendFactor * randomFactor);
    
    result.push({
      date: date.toISOString().split('T')[0],
      impressions: baseImpressions,
      clicks: baseClicks,
      conversions: baseConversions,
      ctr: ((baseClicks / baseImpressions) * 100).toFixed(2),
      convRate: ((baseConversions / baseClicks) * 100).toFixed(2)
    });
  }
  
  return result;
};

const hourlyData = [
  { hour: '00:00', impressions: 1200, clicks: 40 },
  { hour: '02:00', impressions: 800, clicks: 25 },
  { hour: '04:00', impressions: 600, clicks: 15 },
  { hour: '06:00', impressions: 1500, clicks: 45 },
  { hour: '08:00', impressions: 2800, clicks: 95 },
  { hour: '10:00', impressions: 3500, clicks: 120 },
  { hour: '12:00', impressions: 3200, clicks: 110 },
  { hour: '14:00', impressions: 3800, clicks: 130 },
  { hour: '16:00', impressions: 4200, clicks: 145 },
  { hour: '18:00', impressions: 4500, clicks: 160 },
  { hour: '20:00', impressions: 3800, clicks: 130 },
  { hour: '22:00', impressions: 2500, clicks: 85 }
];

const demographicData = [
  { age: '18-24', male: 15, female: 20 },
  { age: '25-34', male: 25, female: 30 },
  { age: '35-44', male: 20, female: 15 },
  { age: '45-54', male: 10, female: 8 },
  { age: '55+', male: 5, female: 2 }
];

export default function CampaignDetails() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [campaign, setCampaign] = useState<CampaignData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const [dateRange, setDateRange] = useState('7d');
  const [dailyData, setDailyData] = useState<any[]>([]);

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const { data: { user }, error } = await supabase.auth.getUser();
        if (error || !user) {
          navigate('/login');
          return;
        }
        
        fetchCampaignData();
      } catch (err) {
        console.error('Auth check error:', err);
        navigate('/login');
      }
    };

    checkAuth();
  }, [navigate, id]);

  useEffect(() => {
    // Generate different data based on date range
    const days = dateRange === '7d' ? 7 : dateRange === '30d' ? 30 : 90;
    const trend = id === 'c1' ? 'up' : id === 'c2' ? 'stable' : 'down';
    setDailyData(generateDailyData(days, trend));
  }, [dateRange, id]);

  const fetchCampaignData = async () => {
    setIsLoading(true);
    try {
      // In a real app, this would fetch from your API
      // For demo purposes, we'll use mock data
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      if (id === 'new') {
        // Handle new campaign creation
        setCampaign(null);
        setIsLoading(false);
        return;
      }
      
      const mockCampaigns = [
        {
          id: 'c1',
          name: 'Summer Promotion',
          status: 'active',
          platform: 'Telegram',
          impressions: 125000,
          clicks: 3750,
          conversions: 450,
          spend: 1200,
          startDate: '2025-01-15',
          endDate: '2025-02-15',
          description: 'Summer promotional campaign targeting users interested in fashion and travel.',
          objective: 'Brand Awareness',
          audience: {
            countries: ['Nigeria', 'Kenya', 'Ghana'],
            ageRange: { min: 18, max: 34 },
            gender: 'all',
            interests: ['Fashion', 'Travel', 'Lifestyle']
          },
          creatives: [
            {
              id: 'cr1',
              type: 'image',
              url: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
              title: 'Summer Collection',
              description: 'Discover our new summer collection with exclusive discounts.'
            }
          ]
        },
        {
          id: 'c2',
          name: 'App Install Campaign',
          status: 'active',
          platform: 'Mobile Games',
          impressions: 85000,
          clicks: 12500,
          conversions: 3200,
          spend: 2500,
          startDate: '2025-01-20',
          endDate: '2025-03-20',
          description: 'Campaign to drive app installations across popular mobile games.',
          objective: 'App Installs',
          audience: {
            countries: ['Nigeria', 'South Africa', 'Kenya', 'Ghana'],
            ageRange: { min: 16, max: 45 },
            gender: 'all',
            interests: ['Gaming', 'Technology', 'Entertainment']
          },
          creatives: [
            {
              id: 'cr2',
              type: 'video',
              url: 'https://example.com/video.mp4',
              title: 'Download Our App',
              description: 'Get started with our app today and enjoy exclusive features.'
            }
          ]
        },
        {
          id: 'c3',
          name: 'Brand Awareness',
          status: 'completed',
          platform: 'Telegram & Mobile Games',
          impressions: 250000,
          clicks: 7500,
          conversions: 900,
          spend: 3000,
          startDate: '2024-12-01',
          endDate: '2025-01-15',
          description: 'Multi-platform campaign to increase brand visibility across Africa.',
          objective: 'Brand Awareness',
          audience: {
            countries: ['Nigeria', 'Kenya', 'South Africa', 'Ghana', 'Ethiopia'],
            ageRange: { min: 18, max: 55 },
            gender: 'all',
            interests: ['Business', 'Technology', 'Lifestyle', 'News']
          },
          creatives: [
            {
              id: 'cr3',
              type: 'image',
              url: 'https://images.unsplash.com/photo-1560472355-536de3962603?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
              title: 'Discover Our Brand',
              description: 'Join thousands of satisfied customers across Africa.'
            }
          ]
        }
      ];
      
      const campaignData = mockCampaigns.find(c => c.id === id);
      
      if (campaignData) {
        setCampaign(campaignData);
      } else {
        // Handle campaign not found
        navigate('/analytics');
      }
    } catch (error) {
      console.error('Error fetching campaign data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleStatusChange = (newStatus: string) => {
    if (!campaign) return;
    
    setCampaign({
      ...campaign,
      status: newStatus
    });
    
    // In a real app, you would call an API to update the status
    console.log(`Campaign status changed to ${newStatus}`);
  };

  const handleDateRangeChange = (range: string) => {
    setDateRange(range);
  };

  const formatNumber = (num: number): string => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    }
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  };

  if (isLoading) {
    return (
      <div className="min-h-screen pt-16 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading campaign details...</p>
        </div>
      </div>
    );
  }

  if (!campaign && id !== 'new') {
    return (
      <div className="min-h-screen pt-16 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600">Campaign not found</p>
          <button
            onClick={() => navigate('/analytics')}
            className="mt-4 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-orange-600 hover:bg-orange-700"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Analytics
          </button>
        </div>
      </div>
    );
  }

  if (id === 'new') {
    return (
      <div className="min-h-screen pt-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-8">
            <button
              onClick={() => navigate('/analytics')}
              className="inline-flex items-center text-sm text-gray-600 hover:text-gray-900"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Analytics
            </button>
            <h1 className="mt-2 text-2xl font-bold text-gray-900">Create New Campaign</h1>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <p className="text-center text-gray-600 py-12">
              Campaign creation form would go here. <br />
              For now, please use the Campaign Creation feature on the homepage.
            </p>
            <div className="flex justify-center">
              <button
                onClick={() => navigate('/')}
                className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-orange-600 hover:bg-orange-700"
              >
                Go to Campaign Creation
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8 flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <button
              onClick={() => navigate('/analytics')}
              className="inline-flex items-center text-sm text-gray-600 hover:text-gray-900"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Analytics
            </button>
            <h1 className="mt-2 text-2xl font-bold text-gray-900">{campaign.name}</h1>
            <div className="flex items-center mt-1">
              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                campaign.status === 'active' ? 'bg-green-100 text-green-800' :
                campaign.status === 'paused' ? 'bg-yellow-100 text-yellow-800' :
                'bg-blue-100 text-blue-800'
              }`}>
                {campaign.status.charAt(0).toUpperCase() + campaign.status.slice(1)}
              </span>
              <span className="ml-2 text-sm text-gray-500">{campaign.platform}</span>
            </div>
          </div>
          
          <div className="mt-4 md:mt-0 flex flex-wrap gap-2">
            {campaign.status === 'active' ? (
              <button
                onClick={() => handleStatusChange('paused')}
                className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
              >
                <Pause className="mr-2 h-4 w-4 text-gray-500" />
                Pause Campaign
              </button>
            ) : campaign.status === 'paused' ? (
              <button
                onClick={() => handleStatusChange('active')}
                className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
              >
                <Play className="mr-2 h-4 w-4 text-green-500" />
                Resume Campaign
              </button>
            ) : null}
            
            <button className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
              <Edit className="mr-2 h-4 w-4 text-gray-500" />
              Edit
            </button>
            
            <button className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
              <Share2 className="mr-2 h-4 w-4 text-gray-500" />
              Share Report
            </button>
            
            <button className="inline-flex items-center px-3 py-2 border border-transparent shadow-sm text-sm leading-4 font-medium rounded-md text-white bg-red-600 hover:bg-red-700">
              <Trash2 className="mr-2 h-4 w-4" />
              Delete
            </button>
          </div>
        </div>

        <div className="mb-6 bg-white rounded-lg shadow-md overflow-hidden">
          <div className="p-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex items-center mb-2">
                  <Eye className="h-5 w-5 text-blue-600" />
                  <span className="ml-2 text-sm text-gray-500">Impressions</span>
                </div>
                <span className="text-2xl font-bold text-gray-900">
                  {formatNumber(campaign.impressions)}
                </span>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex items-center mb-2">
                  <MousePointer className="h-5 w-5 text-green-600" />
                  <span className="ml-2 text-sm text-gray-500">Clicks</span>
                </div>
                <span className="text-2xl font-bold text-gray-900">
                  {formatNumber(campaign.clicks)}
                </span>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex items-center mb-2">
                  <ShoppingCart className="h-5 w-5 text-purple-600" />
                  <span className="ml-2 text-sm text-gray-500">Conversions</span>
                </div>
                <span className="text-2xl font-bold text-gray-900">
                  {formatNumber(campaign.conversions)}
                </span>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex items-center mb-2">
                  <DollarSign className="h-5 w-5 text-red-600" />
                  <span className="ml-2 text-sm text-gray-500">Spend</span>
                </div>
                <span className="text-2xl font-bold text-gray-900">
                  ${campaign.spend.toLocaleString()}
                </span>
              </div>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-6">
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex items-center mb-2">
                  <TrendingUp className="h-5 w-5 text-yellow-600" />
                  <span className="ml-2 text-sm text-gray-500">CTR</span>
                </div>
                <span className="text-2xl font-bold text-gray-900">
                  {((campaign.clicks / campaign.impressions) * 100).toFixed(2)}%
                </span>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex items-center mb-2">
                  <BarChart3 className="h-5 w-5 text-indigo-600" />
                  <span className="ml-2 text-sm text-gray-500">Conversion Rate</span>
                </div>
                <span className="text-2xl font-bold text-gray-900">
                  {((campaign.conversions / campaign.clicks) * 100).toFixed(2)}%
                </span>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex items-center mb-2">
                  <Calendar className="h-5 w-5 text-orange-600" />
                  <span className="ml-2 text-sm text-gray-500">Start Date</span>
                </div>
                <span className="text-lg font-medium text-gray-900">
                  {new Date(campaign.startDate).toLocaleDateString()}
                </span>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex items-center mb-2">
                  <Clock className="h-5 w-5 text-teal-600" />
                  <span className="ml-2 text-sm text-gray-500">End Date</span>
                </div>
                <span className="text-lg font-medium text-gray-900">
                  {new Date(campaign.endDate).toLocaleDateString()}
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="mb-6">
          <div className="sm:hidden">
            <select
              id="tabs"
              name="tabs"
              className="block w-full rounded-md border-gray-300 focus:border-orange-500 focus:ring-orange-500"
              value={activeTab}
              onChange={(e) => setActiveTab(e.target.value)}
            >
              <option value="overview">Overview</option>
              <option value="audience">Audience</option>
              <option value="creatives">Creatives</option>
              <option value="settings">Settings</option>
            </select>
          </div>
          <div className="hidden sm:block">
            <div className="border-b border-gray-200">
              <nav className="-mb-px flex space-x-8" aria-label="Tabs">
                {['overview', 'audience', 'creatives', 'settings'].map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`
                      whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm
                      ${activeTab === tab
                        ? 'border-orange-500 text-orange-600'
                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}
                    `}
                  >
                    {tab.charAt(0).toUpperCase() + tab.slice(1)}
                  </button>
                ))}
              </nav>
            </div>
          </div>
        </div>

        {activeTab === 'overview' && (
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
                <h2 className="text-lg font-medium text-gray-900">Performance Over Time</h2>
                <div className="flex items-center space-x-2 bg-white rounded-md shadow-sm p-1">
                  {['7d', '30d', '90d'].map((range) => (
                    <button
                      key={range}
                      onClick={() => handleDateRangeChange(range)}
                      className={`px-3 py-1 text-sm rounded-md ${
                        dateRange === range 
                          ? 'bg-orange-600 text-white' 
                          : 'text-gray-600 hover:bg-gray-100'
                      }`}
                    >
                      {range === '7d' ? '7 Days' : 
                       range === '30d' ? '30 Days' : 
                       '90 Days'}
                    </button>
                  ))}
                </div>
              </div>
              <div className="p-6">
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={dailyData}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis yAxisId="left" orientation="left" stroke="#8884d8" />
                      <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
                      <Tooltip />
                      <Line yAxisId="left" type="monotone" dataKey="impressions" stroke="#8884d8" name="Impressions" />
                      <Line yAxisId="right" type="monotone" dataKey="clicks" stroke="#82ca9d" name="Clicks" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="px-6 py-4 border-b border-gray-200">
                  <h2 className="text-lg font-medium text-gray-900">Hourly Performance</h2>
                </div>
                <div className="p-6">
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart
                        data={hourlyData}
                        margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="hour" />
                        <YAxis />
                        <Tooltip />
                        <Area type="monotone" dataKey="impressions" stroke="#8884d8" fill="#8884d8" fillOpacity={0.3} />
                        <Area type="monotone" dataKey="clicks" stroke="#82ca9d" fill="#82ca9d" fillOpacity={0.3} />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="px-6 py-4 border-b border-gray-200">
                  <h2 className="text-lg font-medium text-gray-900">Campaign Details</h2>
                </div>
                <div className="p-6">
                  <dl className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2">
                    <div className="sm:col-span-2">
                      <dt className="text-sm font-medium text-gray-500">Description</dt>
                      <dd className="mt-1 text-sm text-gray-900">{campaign.description}</dd>
                    </div>
                    <div>
                      <dt className="text-sm font-medium text-gray-500">Objective</dt>
                      <dd className="mt-1 text-sm text-gray-900">{campaign.objective}</dd>
                    </div>
                    <div>
                      <dt className="text-sm font-medium text-gray-500">Platform</dt>
                      <dd className="mt-1 text-sm text-gray-900">{campaign.platform}</dd>
                    </div>
                    <div>
                      <dt className="text-sm font-medium text-gray-500">Start Date</dt>
                      <dd className="mt-1 text-sm text-gray-900">{new Date(campaign.startDate).toLocaleDateString()}</dd>
                    </div>
                    <div>
                      <dt className="text-sm font-medium text-gray-500">End Date</dt>
                      <dd className="mt-1 text-sm text-gray-900">{new Date(campaign.endDate).toLocaleDateString()}</dd>
                    </div>
                    <div>
                      <dt className="text-sm font-medium text-gray-500">Total Budget</dt>
                      <dd className="mt-1 text-sm text-gray-900">${campaign.spend.toLocaleString()}</dd>
                    </div>
                    <div>
                      <dt className="text-sm font-medium text-gray-500">Status</dt>
                      <dd className="mt-1 text-sm text-gray-900 capitalize">{campaign.status}</dd>
                    </div>
                  </dl>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'audience' && (
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-lg font-medium text-gray-900">Audience Demographics</h2>
              </div>
              <div className="p-6">
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={demographicData}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                      layout="vertical"
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" />
                      <YAxis dataKey="age" type="category" />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="male" name="Male" fill="#3b82f6" />
                      <Bar dataKey="female" name="Female" fill="#ec4899" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-lg font-medium text-gray-900">Targeting Settings</h2>
              </div>
              <div className="p-6">
                <dl className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2">
                  <div>
                    <dt className="text-sm font-medium text-gray-500">Countries</dt>
                    <dd className="mt-1 text-sm text-gray-900">
                      {campaign.audience?.countries.join(', ')}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-gray-500">Age Range</dt>
                    <dd className="mt-1 text-sm text-gray-900">
                      {campaign.audience?.ageRange.min} - {campaign.audience?.ageRange.max}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-gray-500">Gender</dt>
                    <dd className="mt-1 text-sm text-gray-900 capitalize">
                      {campaign.audience?.gender}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-gray-500">Interests</dt>
                    <dd className="mt-1 text-sm text-gray-900">
                      {campaign.audience?.interests.join(', ')}
                    </dd>
                  </div>
                </dl>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'creatives' && (
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
                <h2 className="text-lg font-medium text-gray-900">Ad Creatives</h2>
                <button className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                  Add Creative
                </button>
              </div>
              <div className="p-6">
                {campaign.creatives && campaign.creatives.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {campaign.creatives.map((creative) => (
                      <div key={creative.id} className="border border-gray-200 rounded-lg overflow-hidden">
                        <div className="aspect-w-16 aspect-h-9 bg-gray-100">
                          {creative.type === 'image' ? (
                            <img
                              src={creative.url}
                              alt={creative.title}
                              className="object-cover w-full h-full"
                            />
                          ) : (
                            <div className="flex items-center justify-center h-full">
                              <p className="text-gray-500">Video Preview</p>
                            </div>
                          )}
                        </div>
                        <div className="p-4">
                          <h3 className="text-lg font-medium text-gray-900">{creative.title}</h3>
                          <p className="mt-1 text-sm text-gray-500">{creative.description}</p>
                          <div className="mt-4 flex justify-end space-x-2">
                            <button className="inline-flex items-center px-2.5 py-1.5 border border-gray-300 shadow-sm text-xs font-medium rounded text-gray-700 bg-white hover:bg-gray-50">
                              Edit
                            </button>
                            <button className="inline-flex items-center px-2.5 py-1.5 border border-transparent shadow-sm text-xs font-medium rounded text-white bg-red-600 hover:bg-red-700">
                              Delete
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Users className="mx-auto h-12 w-12 text-gray-400" />
                    <h3 className="mt-2 text-sm font-medium text-gray-900">No creatives</h3>
                    <p className="mt-1 text-sm text-gray-500">
                      Get started by adding a new creative.
                    </p>
                    <div className="mt-6">
                      <button
                        type="button"
                        className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-orange-600 hover:bg-orange-700"
                      >
                        Add Creative
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-lg font-medium text-gray-900">Campaign Settings</h2>
              </div>
              <div className="p-6">
                <form className="space-y-6">
                  <div>
                    <label htmlFor="campaign-name" className="block text-sm font-medium text-gray-700">
                      Campaign Name
                    </label>
                    <input
                      type="text"
                      name="campaign-name"
                      id="campaign-name"
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm"
                      defaultValue={campaign.name}
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="campaign-objective" className="block text-sm font-medium text-gray-700">
                      Campaign Objective
                    </label>
                    <select
                      id="campaign-objective"
                      name="campaign-objective"
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm"
                      defaultValue={campaign.objective}
                    >
                      <option>Brand Awareness</option>
                      <option>Lead Generation</option>
                      <option>App Installs</option>
                      <option>Website Traffic</option>
                      <option>Sales & Conversions</option>
                    </select>
                  </div>
                  
                  <div className="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-2">
                    <div>
                      <label htmlFor="start-date" className="block text-sm font-medium text-gray-700">
                        Start Date
                      </label>
                      <input
                        type="date"
                        name="start-date"
                        id="start-date"
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm"
                        defaultValue={campaign.startDate}
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="end-date" className="block text-sm font-medium text-gray-700">
                        End Date
                      </label>
                      <input
                        type="date"
                        name="end-date"
                        id="end-date"
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm"
                        defaultValue={campaign.endDate}
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label htmlFor="campaign-budget" className="block text-sm font-medium text-gray-700">
                      Budget (USD)
                    </label>
                    <input
                      type="number"
                      name="campaign-budget"
                      id="campaign-budget"
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm"
                      defaultValue={campaign.spend}
                    />
                  </div>
                  
                  <div className="flex justify-end">
                    <button
                      type="button"
                      className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="ml-3 inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-orange-600 hover:bg-orange-700"
                    >
                      Save Changes
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}