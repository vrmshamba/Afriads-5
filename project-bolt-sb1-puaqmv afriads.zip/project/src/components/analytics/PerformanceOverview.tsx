import React from 'react';
import { 
  Eye, 
  MousePointer, 
  ShoppingCart, 
  TrendingUp, 
  DollarSign, 
  BarChart3,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface PerformanceProps {
  performance: {
    impressions: number;
    clicks: number;
    conversions: number;
    ctr: number;
    conversionRate: number;
    spend: number;
    roi: number;
  }
}

export default function PerformanceOverview({ performance }: PerformanceProps) {
  const formatNumber = (num: number): string => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    }
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toFixed(0);
  };

  const metrics = [
    { 
      name: 'Impressions', 
      value: performance.impressions, 
      icon: Eye, 
      change: 12.5, 
      format: formatNumber,
      color: 'text-blue-600'
    },
    { 
      name: 'Clicks', 
      value: performance.clicks, 
      icon: MousePointer, 
      change: 8.3, 
      format: formatNumber,
      color: 'text-green-600'
    },
    { 
      name: 'Conversions', 
      value: performance.conversions, 
      icon: ShoppingCart, 
      change: 15.2, 
      format: formatNumber,
      color: 'text-purple-600'
    },
    { 
      name: 'CTR', 
      value: performance.ctr, 
      icon: TrendingUp, 
      change: -2.1, 
      format: (val: number) => val.toFixed(2) + '%',
      color: 'text-yellow-600'
    },
    { 
      name: 'Conversion Rate', 
      value: performance.conversionRate, 
      icon: BarChart3, 
      change: 5.7, 
      format: (val: number) => val.toFixed(2) + '%',
      color: 'text-indigo-600'
    },
    { 
      name: 'Total Spend', 
      value: performance.spend, 
      icon: DollarSign, 
      change: 10.3, 
      format: (val: number) => '$' + val.toLocaleString(),
      color: 'text-red-600'
    }
  ];

  // Sample data for the chart
  const chartData = [
    { name: 'Mon', impressions: 45000, clicks: 1200 },
    { name: 'Tue', impressions: 52000, clicks: 1350 },
    { name: 'Wed', impressions: 49000, clicks: 1400 },
    { name: 'Thu', impressions: 63000, clicks: 1800 },
    { name: 'Fri', impressions: 58000, clicks: 1650 },
    { name: 'Sat', impressions: 48000, clicks: 1100 },
    { name: 'Sun', impressions: 40000, clicks: 950 }
  ];

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="px-6 py-4 border-b border-gray-200">
        <h2 className="text-lg font-medium text-gray-900">Performance Overview</h2>
      </div>
      
      <div className="p-6">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
          {metrics.map((metric, index) => (
            <div key={index} className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center mb-2">
                <metric.icon className={`h-5 w-5 ${metric.color}`} />
                <span className="ml-2 text-sm text-gray-500">{metric.name}</span>
              </div>
              <div className="flex items-baseline">
                <span className="text-2xl font-bold text-gray-900">
                  {metric.format(metric.value)}
                </span>
                <span className={`ml-2 flex items-center text-sm ${
                  metric.change >= 0 ? 'text-green-600' : 'text-red-600'
                }`}>
                  {metric.change >= 0 ? (
                    <ArrowUpRight className="h-3 w-3 mr-1" />
                  ) : (
                    <ArrowDownRight className="h-3 w-3 mr-1" />
                  )}
                  {Math.abs(metric.change)}%
                </span>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-8 h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={chartData}
              margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis yAxisId="left" orientation="left" stroke="#8884d8" />
              <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
              <Tooltip />
              <Bar yAxisId="left" dataKey="impressions" fill="#8884d8" name="Impressions" />
              <Bar yAxisId="right" dataKey="clicks" fill="#82ca9d" name="Clicks" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="mt-8 bg-orange-50 border border-orange-200 rounded-lg p-4">
          <div className="flex items-center">
            <div className="flex-shrink-0 bg-orange-100 rounded-full p-2">
              <TrendingUp className="h-5 w-5 text-orange-600" />
            </div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-orange-800">ROI Analysis</h3>
              <p className="text-sm text-orange-700 mt-1">
                Your current ROI is <span className="font-bold">{performance.roi}%</span>, which is 
                <span className="font-bold text-green-600"> 15% higher</span> than the industry average.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}