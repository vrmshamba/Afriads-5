import React from 'react';
import { Lightbulb, TrendingUp, Target, Image } from 'lucide-react';

interface Recommendation {
  id: string;
  type: 'optimization' | 'targeting' | 'creative';
  title: string;
  description: string;
  impact: 'low' | 'medium' | 'high';
  confidence: number;
}

interface AIRecommendationsProps {
  recommendations: Recommendation[];
}

export default function AIRecommendations({ recommendations }: AIRecommendationsProps) {
  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high':
        return 'text-green-600';
      case 'medium':
        return 'text-yellow-600';
      case 'low':
        return 'text-blue-600';
      default:
        return 'text-gray-600';
    }
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'optimization':
        return <TrendingUp className="h-5 w-5 text-purple-500" />;
      case 'targeting':
        return <Target className="h-5 w-5 text-blue-500" />;
      case 'creative':
        return <Image className="h-5 w-5 text-orange-500" />;
      default:
        return <Lightbulb className="h-5 w-5 text-yellow-500" />;
    }
  };

  if (recommendations.length === 0) {
    return (
      <div className="text-center py-6">
        <Lightbulb className="mx-auto h-8 w-8 text-gray-400" />
        <p className="mt-2 text-gray-500">No recommendations available yet</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {recommendations.map((rec) => (
        <div key={rec.id} className="bg-gray-50 rounded-lg p-4 border border-gray-200">
          <div className="flex items-start">
            <div className="flex-shrink-0 mt-1">
              {getIcon(rec.type)}
            </div>
            <div className="ml-3 flex-1">
              <h4 className="text-sm font-medium text-gray-900">{rec.title}</h4>
              <p className="mt-1 text-xs text-gray-500">{rec.description}</p>
              <div className="mt-2 flex items-center justify-between">
                <div className="flex items-center">
                  <span className={`text-xs font-medium ${getImpactColor(rec.impact)}`}>
                    {rec.impact.charAt(0).toUpperCase() + rec.impact.slice(1)} impact
                  </span>
                  <span className="mx-2 text-gray-300">|</span>
                  <span className="text-xs text-gray-500">
                    {rec.confidence}% confidence
                  </span>
                </div>
                <button className="text-xs text-orange-600 hover:text-orange-500">
                  Apply
                </button>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}