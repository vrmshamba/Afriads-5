import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  BarChart as BarChartIcon, 
  TrendingUp, 
  RefreshCw,
  Search,
  Download,
  Info
} from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from 'recharts';

export default function CompetitorBenchmark() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [dateRange, setDateRange] = useState('30d');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [industry, setIndustry] = useState('all');

  // Sample data for charts
  const [ctrData, setCtrData] = useState([
    { name: 'Your Campaigns', value: 3.2 },
    { name: 'Industry Average', value: 2.1 },
    { name: 'Top Performers', value: 4.5 }
  ]);

  const [conversionData, setConversionData] = useState([
    { name: 'Your Campaigns', value: 2.8 },
    { name: 'Industry Average', value: 1.9 },
    { name: 'Top Performers', value: 3.7 }
  ]);

  const [costData, setCostData] = useState([
    { name: 'Your Campaigns', value: 1.2 },
    { name: 'Industry Average', value: 1.5 },
    { name: 'Top Performers', value: 0.9 }
  ]);

  const [trendsData, setTrendsData] = useState([
    { month: 'Jan', you: 2.1, industry: 1.8, top: 3.2 },
    { month: 'Feb', you: 2.3, industry: 1.9, top: 3.4 },
    { month: 'Mar', you: 2.5, industry: 1.9, top: 3.5 },
    { month: 'Apr', you: 2.2, industry: 2.0, top: 3.6 },
    { month: 'May', you: 2.6, industry: 2.0, top: 3.7 },
    { month: 'Jun', you: 2.8, industry: 2.1, top: 3.9 },
    { month: 'Jul', you: 3.0, industry: 2.1, top: 4.1 },
    { month: 'Aug', you: 3.2, industry: 2.1, top: 4.3 },
    { month: 'Sep', you: 3.1, industry: 2.2, top: 4.4 },
    { month: 'Oct', you: 3.3, industry: 2.2, top: 4.5 },
    { month: 'Nov', you: 3.2, industry: 2.1, top: 4.5 },
    { month: 'Dec', you: 3.2, industry: 2.1, top: 4.5 }
  ]);

  const industries = [
    'All Industries',
    'E-commerce',
    'Finance',
    'Technology',
    'Education',
    'Healthcare',
    'Entertainment',
    'Travel',
    'Food & Beverage'
  ];

  const regions = [
    'All Regions',
    'East Africa',
    'West Africa',
    'Southern Africa',
    'North Africa'
  ];

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const { data: { user }, error } = await supabase.auth.getUser();
        if (error || !user) {
          navigate('/login');
          return;
        }
        
        fetchBenchmarkData();
      } catch (err) {
        console.error('Auth check error:', err);
        navigate('/login');
      }
    };

    checkAuth();
  }, [navigate]);

  const fetchBenchmarkData = async () => {
    setIsLoading(true);
    try {
      // In a real app, this would fetch from your API
      // For demo purposes, we'll use the mock data already defined
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Adjust data based on selected industry
      if (industry === 'e-commerce') {
        setCtrData([
          { name: 'Your Campaigns', value: 3.5 },
          { name: 'Industry Average', value: 2.3 },
          { name: 'Top Performers', value: 4.8 }
        ]);
        setConversionData([
          { name: 'Your Campaigns', value: 3.2 },
          { name: 'Industry Average', value: 2.1 },
          { name: 'Top Performers', value: 4.2 }
        ]);
      } else if (industry === 'technology') {
        setCtrData([
          { name: 'Your Campaigns', value: 2.9 },
          { name: 'Industry Average', value: 1.8 },
          { name: 'Top Performers', value: 4.1 }
        ]);
        setConversionData([
          { name: 'Your Campaigns', value: 2.5 },
          { name: 'Industry Average', value: 1.7 },
          { name: 'Top Performers', value: 3.5 }
        ]);
      }
      
    } catch (error) {
      console.error('Error fetching benchmark data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await fetchBenchmarkData();
    setIsRefreshing(false);
  };

  const handleDateRangeChange = (range: string) => {
    setDateRange(range);
    // In a real app, this would refetch data with the new date range
  };

  const handleIndustryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setIndustry(e.target.value);
    // In a real app, this would refetch data with the new industry filter
  };

  if (isLoading) {
    return (
      <div className="min-h-screen pt-16 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading benchmark data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
          <div>
            <button
              onClick={() => navigate('/analytics')}
              className="inline-flex items-center text-sm text-gray-600 hover:text-gray-900"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Analytics
            </button>
            <h1 className="mt-2 text-2xl font-bold text-gray-900">Competitor Benchmark</h1>
            <p className="text-gray-600">Compare your performance against industry standards</p>
          </div>
          
          <div className="mt-4 md:mt-0 flex items-center space-x-4">
            <div className="flex items-center space-x-2 bg-white rounded-md shadow-sm p-1">
              {['7d', '30d', '90d', 'ytd', 'all'].map((range) => (
                <button
                  key={range}
                  onClick={() => handleDateRangeChange(range)}
                  className={`px-3 py-1 text-sm rounded-md ${
                    dateRange === range 
                      ? 'bg-orange-600 text-white' 
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  {range === '7d' ? 'Week' : 
                   range === '30d' ? 'Month' : 
                   range === '90d' ? 'Quarter' : 
                   range === 'ytd' ? 'Year' : 'All Time'}
                </button>
              ))}
            </div>
            
            <button 
              onClick={handleRefresh}
              disabled={isRefreshing}
              className="flex items-center px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm text-sm text-gray-700 hover:bg-gray-50 disabled:opacity-50"
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
              Refresh
            </button>
            
            <button className="flex items-center px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm text-sm text-gray-700 hover:bg-gray-50">
              <Download className="h-4 w-4 mr-2" />
              Export
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="mb-8 bg-white rounded-lg shadow-md p-4">
          <div className="flex items-center mb-4">
            <Search className="h-5 w-5 text-gray-500 mr-2" />
            <h2 className="text-lg font-medium text-gray-900">Filter Benchmark Data</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="industry" className="block text-sm font-medium text-gray-700">
                Industry
              </label>
              <select
                id="industry"
                value={industry}
                onChange={handleIndustryChange}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm"
              >
                {industries.map((ind) => (
                  <option key={ind} value={ind.toLowerCase().replace(/\s+/g, '-')}>
                    {ind}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="region" className="block text-sm font-medium text-gray-700">
                Region
              </label>
              <select
                id="region"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500 sm:text-sm"
              >
                {regions.map((region) => (
                  <option key={region} value={region.toLowerCase().replace(/\s+/g, '-')}>
                    {region}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Info Banner */}
        <div className="mb-8 bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <Info className="h-5 w-5 text-blue-400" />
            </div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-blue-800">About Benchmark Data</h3>
              <div className="mt-2 text-sm text-blue-700">
                <p>
                  Benchmark data is compiled from anonymized performance metrics across thousands of campaigns in your industry.
                  "Top Performers" represents the top 10% of campaigns in each category.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          {/* CTR Benchmark */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200">
              <div className="flex items-center">
                <BarChartIcon className="h-5 w-5 text-orange-600 mr-2" />
                <h2 className="text-lg font-medium text-gray-900">Click-Through Rate (CTR)</h2>
              </div>
            </div>
            <div className="p-6">
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={ctrData}
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip formatter={(value) => `${value}%`} />
                    <Bar dataKey="value" fill="#8884d8" name="CTR %" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-4 text-center">
                <p className="text-sm text-gray-500">Your CTR is <span className="font-medium text-green-600">52% higher</span> than industry average</p>
              </div>
            </div>
          </div>

          {/* Conversion Rate Benchmark */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200">
              <div className="flex items-center">
                <BarChartIcon className="h-5 w-5 text-orange-600 mr-2" />
                <h2 className="text-lg font-medium text-gray-900">Conversion Rate</h2>
              </div>
            </div>
            <div className="p-6">
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={conversionData}
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip formatter={(value) => `${value}%`} />
                    <Bar dataKey="value" fill="#82ca9d" name="Conversion %" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-4 text-center">
                <p className="text-sm text-gray-500">Your conversion rate is <span className="font-medium text-green-600">47% higher</span> than industry average</p>
              </div>
            </div>
          </div>

          {/* Cost Per Acquisition Benchmark */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200">
              <div className="flex items-center">
                <BarChartIcon className="h-5 w-5 text-orange-600 mr-2" />
                <h2 className="text-lg font-medium text-gray-900">Cost Per Acquisition</h2>
              </div>
            </div>
            <div className="p-6">
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={costData}
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip formatter={(value) => `$${value}`} />
                    <Bar dataKey="value" fill="#ff8042" name="CPA ($)" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-4 text-center">
                <p className="text-sm text-gray-500">Your CPA is <span className="font-medium text-green-600">20% lower</span> than industry average</p>
              </div>
            </div>
          </div>
        </div>

        {/* Performance Trends */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex items-center">
              <TrendingUp className="h-5 w-5 text-orange-600 mr-2" />
              <h2 className="text-lg font-medium text-gray-900">Performance Trends (CTR %)</h2>
            </div>
          </div>
          <div className="p-6">
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={trendsData}
                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip formatter={(value) => `${value}%`} />
                  <Legend />
                  <Line type="monotone" dataKey="you" stroke="#8884d8" name="Your Campaigns" activeDot={{ r: 8 }} />
                  <Line type="monotone" dataKey="industry" stroke="#82ca9d" name="Industry Average" />
                  <Line type="monotone" dataKey="top" stroke="#ff8042" name="Top Performers" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Recommendations */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-lg font-medium text-gray-900">Improvement Opportunities</h2>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <h3 className="text-sm font-medium text-green-800">Strengths</h3>
                <ul className="mt-2 text-sm text-green-700 list-disc list-inside">
                  <li>Your CTR is significantly higher than industry average</li>
                  <li>Your conversion rate has been steadily improving over the last 6 months</li>
                  <li>Your cost per acquisition is lower than both industry average and top performers</li>
                </ul>
              </div>
              
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <h3 className="text-sm font-medium text-yellow-800">Opportunities</h3>
                <ul className="mt-2 text-sm text-yellow-700 list-disc list-inside">
                  <li>Your mobile engagement is 15% below top performers</li>
                  <li>Your ad frequency could be optimized to match top performers (currently 2.3 vs 1.8)</li>
                  <li>Consider expanding to new regions where competitors are seeing strong results</li>
                </ul>
              </div>
              
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h3 className="text-sm font-medium text-blue-800">Recommendations</h3>
                <ul className="mt-2 text-sm text-blue-700 list-disc list-inside">
                  <li>Optimize mobile ad formats to improve engagement</li>
                  <li>Reduce ad frequency to match top performers' best practices</li>
                  <li>Test campaigns in East Africa where your industry is seeing 25% higher engagement</li>
                  <li>Increase video ad allocation to match top performers (currently 15% vs 35%)</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}