import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  TrendingUp, 
  BarChart as BarChartIcon, 
  Calendar, 
  RefreshCw,
  Download,
  Zap,
  AlertTriangle,
  Check
} from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area } from 'recharts';

export default function PredictiveAnalytics() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [forecastPeriod, setForecastPeriod] = useState('30d');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [confidenceLevel, setConfidenceLevel] = useState('medium');

  // Sample data for charts
  const [impressionsForecast, setImpressionsForecast] = useState([
    { date: '2025-03-01', actual: 45000, forecast: null, lower: null, upper: null },
    { date: '2025-03-08', actual: 48000, forecast: null, lower: null, upper: null },
    { date: '2025-03-15', actual: 52000, forecast: null, lower: null, upper: null },
    { date: '2025-03-22', actual: 49000, forecast: null, lower: null, upper: null },
    { date: '2025-03-29', actual: 53000, forecast: null, lower: null, upper: null },
    { date: '2025-04-05', actual: null, forecast: 55000, lower: 52000, upper: 58000 },
    { date: '2025-04-12', actual: null, forecast: 57000, lower: 53000, upper: 61000 },
    { date: '2025-04-19', actual: null, forecast: 59000, lower: 54000, upper: 64000 },
    { date: '2025-04-26', actual: null, forecast: 62000, lower: 56000, upper: 68000 }
  ]);

  const [conversionsForecast, setConversionsForecast] = useState([
    { date: '2025-03-01', actual: 1200, forecast: null, lower: null, upper: null },
    { date: '2025-03-08', actual: 1350, forecast: null, lower: null, upper: null },
    { date: '2025-03-15', actual: 1450, forecast: null, lower: null, upper: null },
    { date: '2025-03-22', actual: 1380, forecast: null, lower: null, upper: null },
    { date: '2025-03-29', actual: 1520, forecast: null, lower: null, upper: null },
    { date: '2025-04-05', actual: null, forecast: 1600, lower: 1450, upper: 1750 },
    { date: '2025-04-12', actual: null, forecast: 1680, lower: 1500, upper: 1860 },
    { date: '2025-04-19', actual: null, forecast: 1750, lower: 1550, upper: 1950 },
    { date: '2025-04-26', actual: null, forecast: 1830, lower: 1600, upper: 2060 }
  ]);

  const [roiForecast, setRoiForecast] = useState([
    { date: '2025-03-01', actual: 220, forecast: null, lower: null, upper: null },
    { date: '2025-03-08', actual: 235, forecast: null, lower: null, upper: null },
    { date: '2025-03-15', actual: 250, forecast: null, lower: null, upper: null },
    { date: '2025-03-22', actual: 245, forecast: null, lower: null, upper: null },
    { date: '2025-03-29', actual: 260, forecast: null, lower: null, upper: null },
    { date: '2025-04-05', actual: null, forecast: 275, lower: 255, upper: 295 },
    { date: '2025-04-12', actual: null, forecast: 290, lower: 265, upper: 315 },
    { date: '2025-04-19', actual: null, forecast: 305, lower: 275, upper: 335 },
    { date: '2025-04-26', actual: null, forecast: 320, lower: 285, upper: 355 }
  ]);

  const [anomalies, setAnomalies] = useState([
    {
      id: 'a1',
      date: '2025-03-10',
      metric: 'CTR',
      value: 5.2,
      expected: 2.8,
      severity: 'high',
      description: 'Significant CTR spike in East Africa region'
    },
    {
      id: 'a2',
      date: '2025-03-18',
      metric: 'Conversion Rate',
      value: 0.8,
      expected: 2.1,
      severity: 'medium',
      description: 'Conversion rate drop in mobile game ads'
    }
  ]);

  const [recommendations, setRecommendations] = useState([
    {
      id: 'r1',
      title: 'Increase budget allocation to East Africa',
      description: 'Based on forecasted performance, increasing budget by 20% could yield 35% higher ROI',
      impact: 'high',
      confidence: 85
    },
    {
      id: 'r2',
      title: 'Optimize mobile game ad creatives',
      description: 'Current conversion rates are below forecast. Refreshing creatives could improve performance',
      impact: 'medium',
      confidence: 72
    },
    {
      id: 'r3',
      title: 'Prepare for seasonal trend in April',
      description: 'Historical data shows 15% increase in engagement during April. Consider preparing special campaigns',
      impact: 'medium',
      confidence: 78
    }
  ]);

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const { data: { user }, error } = await supabase.auth.getUser();
        if (error || !user) {
          navigate('/login');
          return;
        }
        
        fetchPredictiveData();
      } catch (err) {
        console.error('Auth check error:', err);
        navigate('/login');
      }
    };

    checkAuth();
  }, [navigate]);

  const fetchPredictiveData = async () => {
    setIsLoading(true);
    try {
      // In a real app, this would fetch from your API
      // For demo purposes, we'll use the mock data already defined
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Adjust forecast data based on selected period
      if (forecastPeriod === '60d') {
        // Add more forecast points for 60 days
        setImpressionsForecast(prev => [
          ...prev,
          { date: '2025-05-03', actual: null, forecast: 64000, lower: 57000, upper: 71000 },
          { date: '2025-05-10', actual: null, forecast: 66000, lower: 58000, upper: 74000 },
          { date: '2025-05-17', actual: null, forecast: 68000, lower: 59000, upper: 77000 },
          { date: '2025-05-24', actual: null, forecast: 70000, lower: 60000, upper: 80000 }
        ]);
      }
      
      // Adjust confidence intervals based on selected confidence level
      if (confidenceLevel === 'high') {
        // Narrow confidence intervals for high confidence
        setImpressionsForecast(prev => 
          prev.map(item => {
            if (item.lower !== null && item.upper !== null) {
              const forecast = item.forecast || 0;
              const range = (item.upper - item.lower) / 2;
              return {
                ...item,
                lower: forecast - range * 0.7,
                upper: forecast + range * 0.7
              };
            }
            return item;
          })
        );
      } else if (confidenceLevel === 'low') {
        // Wider confidence intervals for low confidence
        setImpressionsForecast(prev => 
          prev.map(item => {
            if (item.lower !== null && item.upper !== null) {
              const forecast = item.forecast || 0;
              const range = (item.upper - item.lower) / 2;
              return {
                ...item,
                lower: forecast - range * 1.3,
                upper: forecast + range * 1.3
              };
            }
            return item;
          })
        );
      }
      
    } catch (error) {
      console.error('Error fetching predictive data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await fetchPredictiveData();
    setIsRefreshing(false);
  };

  const handleForecastPeriodChange = (period: string) => {
    setForecastPeriod(period);
    fetchPredictiveData();
  };

  const handleConfidenceLevelChange = (level: string) => {
    setConfidenceLevel(level);
    fetchPredictiveData();
  };

  if (isLoading) {
    return (
      <div className="min-h-screen pt-16 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading predictive analytics...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
          <div>
            <button
              onClick={() => navigate('/analytics')}
              className="inline-flex items-center text-sm text-gray-600 hover:text-gray-900"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Analytics
            </button>
            <h1 className="mt-2 text-2xl font-bold text-gray-900">Predictive Analytics</h1>
            <p className="text-gray-600">AI-powered forecasts and recommendations</p>
          </div>
          
          <div className="mt-4 md:mt-0 flex items-center space-x-4">
            <button 
              onClick={handleRefresh}
              disabled={isRefreshing}
              className="flex items-center px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm text-sm text-gray-700 hover:bg-gray-50 disabled:opacity-50"
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
              Refresh
            </button>
            
            <button className="flex items-center px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm text-sm text-gray-700 hover:bg-gray-50">
              <Download className="h-4 w-4 mr-2" />
              Export
            </button>
          </div>
        </div>

        {/* Forecast Controls */}
        <div className="mb-8 bg-white rounded-lg shadow-md p-4">
          <div className="flex items-center mb-4">
            <Calendar className="h-5 w-5 text-gray-500 mr-2" />
            <h2 className="text-lg font-medium text-gray-900">Forecast Settings</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Forecast Period
              </label>
              <div className="mt-1 flex rounded-md shadow-sm">
                {['30d', '60d', '90d'].map((period) => (
                  <button
                    key={period}
                    onClick={() => handleForecastPeriodChange(period)}
                    className={`relative inline-flex items-center px-4 py-2 border ${
                      forecastPeriod === period
                        ? 'bg-orange-600 text-white border-orange-600 z-10'
                        : 'border-gray-300 bg-white text-gray-700'
                    } text-sm font-medium first:rounded-l-md last:rounded-r-md focus:z-10 focus:outline-none`}
                  >
                    {period === '30d' ? '30 Days' : 
                     period === '60d' ? '60 Days' : 
                     '90 Days'}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Confidence Level
              </label>
              <div className="mt-1 flex rounded-md shadow-sm">
                {['low', 'medium', 'high'].map((level) => (
                  <button
                    key={level}
                    onClick={() => handleConfidenceLevelChange(level)}
                    className={`relative inline-flex items-center px-4 py-2 border ${
                      confidenceLevel === level
                        ? 'bg-orange-600 text-white border-orange-600 z-10'
                        : 'border-gray-300 bg-white text-gray-700'
                    } text-sm font-medium first:rounded-l-md last:rounded-r-md focus:z-10 focus:outline-none capitalize`}
                  >
                    {level}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Impressions Forecast */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex items-center">
              <TrendingUp className="h-5 w-5 text-orange-600 mr-2" />
              <h2 className="text-lg font-medium text-gray-900">Impressions Forecast</h2>
            </div>
          </div>
          <div className="p-6">
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={impressionsForecast}
                  margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Area type="monotone" dataKey="actual" stroke="#8884d8" fill="#8884d8" name="Actual" />
                  <Area type="monotone" dataKey="forecast" stroke="#82ca9d" fill="#82ca9d" name="Forecast" />
                  <Area type="monotone" dataKey="upper" stroke="transparent" fill="#82ca9d" fillOpacity={0.2} name="Upper Bound" />
                  <Area type="monotone" dataKey="lower" stroke="transparent" fill="#82ca9d" fillOpacity={0.2} name="Lower Bound" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 text-center">
              <p className="text-sm text-gray-500">Forecast predicts a <span className="font-medium text-green-600">17% increase</span> in impressions over the next {forecastPeriod === '30d' ? '30' : forecastPeriod === '60d' ? '60' : '90'} days</p>
            </div>
          </div>
        </div>

        {/* Conversions Forecast */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex items-center">
              <TrendingUp className="h-5 w-5 text-orange-600 mr-2" />
              <h2 className="text-lg font-medium text-gray-900">Conversions Forecast</h2>
            </div>
          </div>
          <div className="p-6">
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={conversionsForecast}
                  margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Area type="monotone" dataKey="actual" stroke="#8884d8" fill="#8884d8" name="Actual" />
                  <Area type="monotone" dataKey="forecast" stroke="#82ca9d" fill="#82ca9d" name="Forecast" />
                  <Area type="monotone" dataKey="upper" stroke="transparent" fill="#82ca9d" fillOpacity={0.2} name="Upper Bound" />
                  <Area type="monotone" dataKey="lower" stroke="transparent" fill="#82ca9d" fillOpacity={0.2} name="Lower Bound" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 text-center">
              <p className="text-sm text-gray-500">Forecast predicts a <span className="font-medium text-green-600">20% increase</span> in conversions over the next {forecastPeriod === '30d' ? '30' : forecastPeriod === '60d' ? '60' : '90'} days</p>
            </div>
          </div>
        </div>

        {/* ROI Forecast */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex items-center">
              <TrendingUp className="h-5 w-5 text-orange-600 mr-2" />
              <h2 className="text-lg font-medium text-gray-900">ROI Forecast (%)</h2>
            </div>
          </div>
          <div className="p-6">
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={roiForecast}
                  margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Area type="monotone" dataKey="actual" stroke="#8884d8" fill="#8884d8" name="Actual" />
                  <Area type="monotone" dataKey="forecast" stroke="#82ca9d" fill="#82ca9d" name="Forecast" />
                  <Area type="monotone" dataKey="upper" stroke="transparent" fill="#82ca9d" fillOpacity={0.2} name="Upper Bound" />
                  <Area type="monotone" dataKey="lower" stroke="transparent" fill="#82ca9d" fillOpacity={0.2} name="Lower Bound" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 text-center">
              <p className="text-sm text-gray-500">Forecast predicts a <span className="font-medium text-green-600">23% increase</span> in ROI over the next {forecastPeriod === '30d' ? '30' : forecastPeriod === '60d' ? '60' : '90'} days</p>
            </div>
          </div>
        </div>

        {/* Anomalies */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex items-center">
              <AlertTriangle className="h-5 w-5 text-orange-600 mr-2" />
              <h2 className="text-lg font-medium text-gray-900">Detected Anomalies</h2>
            </div>
          </div>
          <div className="p-6">
            {anomalies.length > 0 ? (
              <div className="space-y-4">
                {anomalies.map((anomaly) => (
                  <div 
                    key={anomaly.id}
                    className={`p-4 rounded-lg border ${
                      anomaly.severity === 'high' 
                        ? 'bg-red-50 border-red-200' 
                        : anomaly.severity === 'medium'
                        ? 'bg-yellow-50 border-yellow-200'
                        : 'bg-blue-50 border-blue-200'
                    }`}
                  >
                    <div className="flex items-start">
                      <AlertTriangle className={`h-5 w-5 mt-0.5 ${
                        anomaly.severity === 'high' 
                          ? 'text-red-500' 
                          : anomaly.severity === 'medium'
                          ? 'text-yellow-500'
                          : 'text-blue-500'
                      }`} />
                      <div className="ml-3">
                        <h3 className={`text-sm font-medium ${
                          anomaly.severity === 'high' 
                            ? 'text-red-800' 
                            : anomaly.severity === 'medium'
                            ? 'text-yellow-800'
                            : 'text-blue-800'
                        }`}>
                          {anomaly.metric} Anomaly Detected
                        </h3>
                        <div className="mt-2 text-sm">
                          <p className={`${
                            anomaly.severity === 'high' 
                              ? 'text-red-700' 
                              : anomaly.severity === 'medium'
                              ? 'text-yellow-700'
                              : 'text-blue-700'
                          }`}>
                            {anomaly.description}
                          </p>
                          <p className="mt-1">
                            <span className="font-medium">Date:</span> {anomaly.date} | 
                            <span className="font-medium"> Actual:</span> {anomaly.value}% | 
                            <span className="font-medium"> Expected:</span> {anomaly.expected}%
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6">
                <Check className="mx-auto h-12 w-12 text-green-500" />
                <h3 className="mt-2 text-sm font-medium text-gray-900">No anomalies detected</h3>
                <p className="mt-1 text-sm text-gray-500">All metrics are within expected ranges</p>
              </div>
            )}
          </div>
        </div>

        {/* AI Recommendations */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex items-center">
              <Zap className="h-5 w-5 text-orange-600 mr-2" />
              <h2 className="text-lg font-medium text-gray-900">AI Recommendations</h2>
            </div>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {recommendations.map((rec) => (
                <div key={rec.id} className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                  <div className="flex items-start">
                    <Zap className="h-5 w-5 text-orange-500 mt-0.5" />
                    <div className="ml-3 flex-1">
                      <h4 className="text-sm font-medium text-gray-900">{rec.title}</h4>
                      <p className="mt-1 text-sm text-gray-500">{rec.description}</p>
                      <div className="mt-2 flex items-center justify-between">
                        <div className="flex items-center">
                          <span className={`text-xs font-medium ${
                            rec.impact === 'high' ? 'text-green-600' :
                            rec.impact === 'medium' ? 'text-yellow-600' :
                            'text-blue-600'
                          }`}>
                            {rec.impact.charAt(0).toUpperCase() + rec.impact.slice(1)} impact
                          </span>
                          <span className="mx-2 text-gray-300">|</span>
                          <span className="text-xs text-gray-500">
                            {rec.confidence}% confidence
                          </span>
                        </div>
                        <button className="text-xs text-orange-600 hover:text-orange-500">
                          Apply
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}