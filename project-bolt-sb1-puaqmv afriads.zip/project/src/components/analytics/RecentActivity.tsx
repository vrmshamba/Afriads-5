import React from 'react';
import { formatDistanceToNow } from 'date-fns';
import { 
  PlusCircle, 
  DollarSign, 
  CheckCircle, 
  RefreshCw,
  Clock
} from 'lucide-react';

interface Activity {
  id: string;
  type: string;
  campaign: string;
  amount?: number;
  timestamp: string;
}

interface RecentActivityProps {
  activities: Activity[];
}

export default function RecentActivity({ activities }: RecentActivityProps) {
  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'campaign_created':
        return <PlusCircle className="h-5 w-5 text-green-500" />;
      case 'budget_increased':
        return <DollarSign className="h-5 w-5 text-blue-500" />;
      case 'campaign_completed':
        return <CheckCircle className="h-5 w-5 text-purple-500" />;
      case 'creative_updated':
        return <RefreshCw className="h-5 w-5 text-orange-500" />;
      default:
        return <Clock className="h-5 w-5 text-gray-500" />;
    }
  };

  const getActivityText = (activity: Activity) => {
    switch (activity.type) {
      case 'campaign_created':
        return `Campaign "${activity.campaign}" was created`;
      case 'budget_increased':
        return `Budget for "${activity.campaign}" increased by $${activity.amount}`;
      case 'campaign_completed':
        return `Campaign "${activity.campaign}" completed`;
      case 'creative_updated':
        return `Creative for "${activity.campaign}" was updated`;
      default:
        return `Activity on "${activity.campaign}"`;
    }
  };

  if (activities.length === 0) {
    return (
      <div className="text-center py-6">
        <Clock className="mx-auto h-8 w-8 text-gray-400" />
        <p className="mt-2 text-gray-500">No recent activity</p>
      </div>
    );
  }

  return (
    <div className="flow-root">
      <ul className="-mb-8">
        {activities.map((activity, activityIdx) => (
          <li key={activity.id}>
            <div className="relative pb-8">
              {activityIdx !== activities.length - 1 ? (
                <span
                  className="absolute top-5 left-5 -ml-px h-full w-0.5 bg-gray-200"
                  aria-hidden="true"
                />
              ) : null}
              <div className="relative flex items-start space-x-3">
                <div className="relative">
                  <div className="h-10 w-10 rounded-full bg-gray-100 flex items-center justify-center ring-8 ring-white">
                    {getActivityIcon(activity.type)}
                  </div>
                </div>
                <div className="min-w-0 flex-1">
                  <div>
                    <div className="text-sm text-gray-800">
                      {getActivityText(activity)}
                    </div>
                    <p className="mt-0.5 text-sm text-gray-500">
                      {formatDistanceToNow(new Date(activity.timestamp), { addSuffix: true })}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}