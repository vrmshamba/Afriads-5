import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Users, 
  Map, 
  PieChart as PieChartIcon, 
  BarChart as BarChartIcon, 
  Calendar, 
  ArrowLeft,
  Filter,
  Download,
  RefreshCw
} from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function AudienceInsights() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [dateRange, setDateRange] = useState('30d');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [activeFilter, setActiveFilter] = useState('all');

  // Sample data for charts
  const [ageData, setAgeData] = useState([
    { name: '18-24', value: 25 },
    { name: '25-34', value: 35 },
    { name: '35-44', value: 20 },
    { name: '45-54', value: 12 },
    { name: '55+', value: 8 }
  ]);

  const [genderData, setGenderData] = useState([
    { name: 'Male', value: 52 },
    { name: 'Female', value: 48 }
  ]);

  const [regionData, setRegionData] = useState([
    { name: 'East Africa', value: 35 },
    { name: 'West Africa', value: 40 },
    { name: 'Southern Africa', value: 20 },
    { name: 'North Africa', value: 5 }
  ]);

  const [countryData, setCountryData] = useState([
    { name: 'Nigeria', value: 30 },
    { name: 'Kenya', value: 25 },
    { name: 'South Africa', value: 15 },
    { name: 'Ghana', value: 10 },
    { name: 'Tanzania', value: 8 },
    { name: 'Uganda', value: 7 },
    { name: 'Others', value: 5 }
  ]);

  const [deviceData, setDeviceData] = useState([
    { name: 'Mobile', value: 75 },
    { name: 'Desktop', value: 20 },
    { name: 'Tablet', value: 5 }
  ]);

  const [interestData, setInterestData] = useState([
    { name: 'Technology', value: 65 },
    { name: 'Entertainment', value: 55 },
    { name: 'Sports', value: 45 },
    { name: 'Fashion', value: 40 },
    { name: 'Food', value: 35 },
    { name: 'Travel', value: 30 },
    { name: 'Health', value: 25 }
  ]);

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d', '#ffc658'];

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const { data: { user }, error } = await supabase.auth.getUser();
        if (error || !user) {
          navigate('/login');
          return;
        }
        
        fetchAudienceData();
      } catch (err) {
        console.error('Auth check error:', err);
        navigate('/login');
      }
    };

    checkAuth();
  }, [navigate]);

  const fetchAudienceData = async () => {
    setIsLoading(true);
    try {
      // In a real app, this would fetch from your API
      // For demo purposes, we'll use the mock data already defined
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Apply filters based on activeFilter
      if (activeFilter === 'east_africa') {
        setAgeData([
          { name: '18-24', value: 30 },
          { name: '25-34', value: 40 },
          { name: '35-44', value: 15 },
          { name: '45-54', value: 10 },
          { name: '55+', value: 5 }
        ]);
        setGenderData([
          { name: 'Male', value: 48 },
          { name: 'Female', value: 52 }
        ]);
        setCountryData([
          { name: 'Kenya', value: 45 },
          { name: 'Tanzania', value: 25 },
          { name: 'Uganda', value: 15 },
          { name: 'Congo DRC', value: 8 },
          { name: 'South Sudan', value: 4 },
          { name: 'Somalia', value: 3 }
        ]);
      } else if (activeFilter === 'west_africa') {
        setAgeData([
          { name: '18-24', value: 22 },
          { name: '25-34', value: 38 },
          { name: '35-44', value: 25 },
          { name: '45-54', value: 10 },
          { name: '55+', value: 5 }
        ]);
        setGenderData([
          { name: 'Male', value: 55 },
          { name: 'Female', value: 45 }
        ]);
        setCountryData([
          { name: 'Nigeria', value: 60 },
          { name: 'Ghana', value: 25 },
          { name: 'Senegal', value: 8 },
          { name: 'Côte d\'Ivoire', value: 5 },
          { name: 'Others', value: 2 }
        ]);
      } else if (activeFilter === 'southern_africa') {
        setAgeData([
          { name: '18-24', value: 20 },
          { name: '25-34', value: 30 },
          { name: '35-44', value: 28 },
          { name: '45-54', value: 15 },
          { name: '55+', value: 7 }
        ]);
        setGenderData([
          { name: 'Male', value: 51 },
          { name: 'Female', value: 49 }
        ]);
        setCountryData([
          { name: 'South Africa', value: 55 },
          { name: 'Zambia', value: 15 },
          { name: 'Mozambique', value: 12 },
          { name: 'Zimbabwe', value: 10 },
          { name: 'Others', value: 8 }
        ]);
      }
      
    } catch (error) {
      console.error('Error fetching audience data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await fetchAudienceData();
    setIsRefreshing(false);
  };

  const handleDateRangeChange = (range: string) => {
    setDateRange(range);
    // In a real app, this would refetch data with the new date range
  };

  const handleFilterChange = (filter: string) => {
    setActiveFilter(filter);
    fetchAudienceData();
  };

  if (isLoading) {
    return (
      <div className="min-h-screen pt-16 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading audience insights...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
          <div>
            <button
              onClick={() => navigate('/analytics')}
              className="inline-flex items-center text-sm text-gray-600 hover:text-gray-900"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Analytics
            </button>
            <h1 className="mt-2 text-2xl font-bold text-gray-900">Audience Insights</h1>
            <p className="text-gray-600">Understand your audience demographics and behavior</p>
          </div>
          
          <div className="mt-4 md:mt-0 flex items-center space-x-4">
            <div className="flex items-center space-x-2 bg-white rounded-md shadow-sm p-1">
              {['7d', '30d', '90d', 'ytd', 'all'].map((range) => (
                <button
                  key={range}
                  onClick={() => handleDateRangeChange(range)}
                  className={`px-3 py-1 text-sm rounded-md ${
                    dateRange === range 
                      ? 'bg-orange-600 text-white' 
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  {range === '7d' ? 'Week' : 
                   range === '30d' ? 'Month' : 
                   range === '90d' ? 'Quarter' : 
                   range === 'ytd' ? 'Year' : 'All Time'}
                </button>
              ))}
            </div>
            
            <button 
              onClick={handleRefresh}
              disabled={isRefreshing}
              className="flex items-center px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm text-sm text-gray-700 hover:bg-gray-50 disabled:opacity-50"
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
              Refresh
            </button>
            
            <button className="flex items-center px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm text-sm text-gray-700 hover:bg-gray-50">
              <Download className="h-4 w-4 mr-2" />
              Export
            </button>
          </div>
        </div>

        {/* Region Filter */}
        <div className="mb-8 bg-white rounded-lg shadow-md p-4">
          <div className="flex items-center mb-4">
            <Filter className="h-5 w-5 text-gray-500 mr-2" />
            <h2 className="text-lg font-medium text-gray-900">Filter by Region</h2>
          </div>
          <div className="flex flex-wrap gap-2">
            {[
              { id: 'all', label: 'All Regions' },
              { id: 'east_africa', label: 'East Africa' },
              { id: 'west_africa', label: 'West Africa' },
              { id: 'southern_africa', label: 'Southern Africa' },
              { id: 'north_africa', label: 'North Africa' }
            ].map((filter) => (
              <button
                key={filter.id}
                onClick={() => handleFilterChange(filter.id)}
                className={`px-4 py-2 rounded-md text-sm font-medium ${
                  activeFilter === filter.id
                    ? 'bg-orange-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {filter.label}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Age Distribution */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200">
              <div className="flex items-center">
                <Users className="h-5 w-5 text-orange-600 mr-2" />
                <h2 className="text-lg font-medium text-gray-900">Age Distribution</h2>
              </div>
            </div>
            <div className="p-6">
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={ageData}
                      cx="50%"
                      cy="50%"
                      labelLine={true}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {ageData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => `${value}%`} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Gender Distribution */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200">
              <div className="flex items-center">
                <Users className="h-5 w-5 text-orange-600 mr-2" />
                <h2 className="text-lg font-medium text-gray-900">Gender Distribution</h2>
              </div>
            </div>
            <div className="p-6">
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={genderData}
                      cx="50%"
                      cy="50%"
                      labelLine={true}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      <Cell fill="#0088FE" />
                      <Cell fill="#FF8042" />
                    </Pie>
                    <Tooltip formatter={(value) => `${value}%`} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Regional Distribution */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200">
              <div className="flex items-center">
                <Map className="h-5 w-5 text-orange-600 mr-2" />
                <h2 className="text-lg font-medium text-gray-900">Regional Distribution</h2>
              </div>
            </div>
            <div className="p-6">
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={regionData}
                    layout="vertical"
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis dataKey="name" type="category" width={100} />
                    <Tooltip formatter={(value) => `${value}%`} />
                    <Bar dataKey="value" fill="#8884d8">
                      {regionData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Country Distribution */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200">
              <div className="flex items-center">
                <Map className="h-5 w-5 text-orange-600 mr-2" />
                <h2 className="text-lg font-medium text-gray-900">Country Distribution</h2>
              </div>
            </div>
            <div className="p-6">
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={countryData}
                    layout="vertical"
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis dataKey="name" type="category" width={100} />
                    <Tooltip formatter={(value) => `${value}%`} />
                    <Bar dataKey="value" fill="#8884d8">
                      {countryData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Device Distribution */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200">
              <div className="flex items-center">
                <PieChartIcon className="h-5 w-5 text-orange-600 mr-2" />
                <h2 className="text-lg font-medium text-gray-900">Device Distribution</h2>
              </div>
            </div>
            <div className="p-6">
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={deviceData}
                      cx="50%"
                      cy="50%"
                      labelLine={true}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {deviceData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => `${value}%`} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Interest Distribution */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200">
              <div className="flex items-center">
                <BarChartIcon className="h-5 w-5 text-orange-600 mr-2" />
                <h2 className="text-lg font-medium text-gray-900">Interest Distribution</h2>
              </div>
            </div>
            <div className="p-6">
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={interestData}
                    layout="vertical"
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis dataKey="name" type="category" width={100} />
                    <Tooltip formatter={(value) => `${value}%`} />
                    <Bar dataKey="value" fill="#8884d8">
                      {interestData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}