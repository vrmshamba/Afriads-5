import React, { useState } from 'react';
import { MapPin, Users, Smartphone, Calendar, Globe2, ChevronDown, ChevronUp } from 'lucide-react';

interface TargetingOptionsProps {
  formData: any;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => void;
  onArrayChange: (name: string, value: string[]) => void;
}

export default function TargetingOptions({ formData, onChange, onArrayChange }: TargetingOptionsProps) {
  // Organized by regions
  const regions = {
    "East Africa": ['Kenya', 'Uganda', 'Tanzania', 'Congo DRC', 'South Sudan', 'Somalia', 'Rwanda', 'Burundi', 'Ethiopia'],
    "West Africa": ['Nigeria', 'Ghana', 'Senegal', 'Côte d\'Ivoire', 'Mali', 'Benin', 'Togo', 'Liberia', 'Sierra Leone', 'Guinea'],
    "Southern Africa": ['South Africa', 'Zambia', 'Mozambique', 'Zimbabwe', 'Namibia', 'Botswana', 'Malawi', 'Lesotho', 'Eswatini'],
    "North Africa": ['Egypt', 'Morocco', 'Algeria', 'Tunisia', 'Libya', 'Sudan']
  };
  
  // State to track expanded regions
  const [expandedRegions, setExpandedRegions] = useState<string[]>([]);
  
  // Flatten countries for the form data
  const countries = Object.values(regions).flat();
  
  const languages = ['English', 'Swahili', 'French', 'Arabic', 'Yoruba', 'Zulu', 'Amharic', 'Hausa', 'Igbo', 'Xhosa'];
  const platforms = ['Telegram', 'Mobile Games', 'Both'];
  const interests = [
    'Technology', 'Entertainment', 'Sports', 'Education', 'Business', 'Lifestyle',
    'Fashion', 'Food & Dining', 'Travel', 'Health & Fitness', 'Music', 'Gaming',
    'Shopping', 'Finance', 'Automotive', 'Real Estate'
  ];
  const deviceTypes = ['Smartphone', 'Tablet', 'Desktop'];
  const objectives = [
    'Brand Awareness',
    'Lead Generation',
    'App Installs',
    'Website Traffic',
    'Sales & Conversions',
    'User Engagement'
  ];

  const handleCheckboxChange = (category: string, value: string) => {
    const currentValues = formData[category] || [];
    const newValues = currentValues.includes(value)
      ? currentValues.filter((v: string) => v !== value)
      : [...currentValues, value];
    onArrayChange(category, newValues);
  };

  const toggleRegion = (region: string) => {
    setExpandedRegions(prev => 
      prev.includes(region) 
        ? prev.filter(r => r !== region) 
        : [...prev, region]
    );
  };

  // Helper function to check if all countries in a region are selected
  const isRegionFullySelected = (region: string) => {
    const regionCountries = regions[region as keyof typeof regions];
    return regionCountries.every(country => formData.countries.includes(country));
  };

  // Helper function to check if any country in a region is selected
  const isRegionPartiallySelected = (region: string) => {
    const regionCountries = regions[region as keyof typeof regions];
    return regionCountries.some(country => formData.countries.includes(country));
  };

  // Toggle all countries in a region
  const toggleAllCountriesInRegion = (region: string) => {
    const regionCountries = regions[region as keyof typeof regions];
    
    if (isRegionFullySelected(region)) {
      // If all are selected, unselect all
      const newCountries = formData.countries.filter((country: string) => !regionCountries.includes(country));
      onArrayChange('countries', newCountries);
    } else {
      // If not all are selected, select all
      const currentCountriesNotInRegion = formData.countries.filter((country: string) => !regionCountries.includes(country));
      const newCountries = [...currentCountriesNotInRegion, ...regionCountries];
      onArrayChange('countries', newCountries);
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Campaign Name</label>
        <input
          type="text"
          name="name"
          value={formData.name}
          onChange={onChange}
          className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
          placeholder="Enter campaign name"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Campaign Objective</label>
        <select
          name="objective"
          value={formData.objective}
          onChange={onChange}
          className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
        >
          <option value="">Select Objective</option>
          {objectives.map((objective) => (
            <option key={objective} value={objective}>{objective}</option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Start Date</label>
          <input
            type="date"
            name="startDate"
            value={formData.startDate}
            onChange={onChange}
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">End Date</label>
          <input
            type="date"
            name="endDate"
            value={formData.endDate}
            onChange={onChange}
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          <div className="flex items-center gap-2">
            <Smartphone className="w-4 h-4" />
            Platform
          </div>
        </label>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {platforms.map((platform) => (
            <label key={platform} className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={formData.platforms.includes(platform)}
                onChange={() => handleCheckboxChange('platforms', platform)}
                className="rounded text-orange-600 focus:ring-orange-500"
              />
              <span>{platform}</span>
            </label>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4" />
            Target Countries by Region
          </div>
        </label>
        
        <div className="space-y-4">
          {Object.entries(regions).map(([region, regionCountries]) => (
            <div key={region} className="border border-gray-200 rounded-lg overflow-hidden">
              <div 
                className="bg-gray-50 p-3 flex items-center justify-between cursor-pointer"
                onClick={() => toggleRegion(region)}
              >
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    checked={isRegionFullySelected(region)}
                    onChange={() => toggleAllCountriesInRegion(region)}
                    className="rounded text-orange-600 focus:ring-orange-500 mr-3"
                    // Stop propagation to prevent the region toggle when clicking the checkbox
                    onClick={(e) => e.stopPropagation()}
                  />
                  <span className={`font-medium ${isRegionPartiallySelected(region) ? 'text-orange-600' : 'text-gray-700'}`}>
                    {region}
                  </span>
                </div>
                {expandedRegions.includes(region) ? (
                  <ChevronUp className="h-5 w-5 text-gray-400" />
                ) : (
                  <ChevronDown className="h-5 w-5 text-gray-400" />
                )}
              </div>
              
              {expandedRegions.includes(region) && (
                <div className="p-4 bg-white border-t border-gray-200">
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {regionCountries.map((country) => (
                      <label key={country} className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={formData.countries.includes(country)}
                          onChange={() => handleCheckboxChange('countries', country)}
                          className="rounded text-orange-600 focus:ring-orange-500"
                        />
                        <span>{country}</span>
                      </label>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          <div className="flex items-center gap-2">
            <Globe2 className="w-4 h-4" />
            Languages
          </div>
        </label>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {languages.map((language) => (
            <label key={language} className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={formData.languages.includes(language)}
                onChange={() => handleCheckboxChange('languages', language)}
                className="rounded text-orange-600 focus:ring-orange-500"
              />
              <span>{language}</span>
            </label>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            Target Audience
          </div>
        </label>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Age Range</label>
            <div className="flex items-center space-x-4">
              <input
                type="number"
                name="ageRange.min"
                value={formData.ageRange.min}
                onChange={onChange}
                min="13"
                max="100"
                className="w-24 px-4 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
              />
              <span>to</span>
              <input
                type="number"
                name="ageRange.max"
                value={formData.ageRange.max}
                onChange={onChange}
                min="13"
                max="100"
                className="w-24 px-4 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Gender</label>
            <select
              name="gender"
              value={formData.gender}
              onChange={onChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
            >
              <option value="all">All Genders</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
            </select>
          </div>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            Interests
          </div>
        </label>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {interests.map((interest) => (
            <label key={interest} className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={formData.interests.includes(interest)}
                onChange={() => handleCheckboxChange('interests', interest)}
                className="rounded text-orange-600 focus:ring-orange-500"
              />
              <span>{interest}</span>
            </label>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Device Types</label>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {deviceTypes.map((device) => (
            <label key={device} className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={formData.deviceTypes.includes(device)}
                onChange={() => handleCheckboxChange('deviceTypes', device)}
                className="rounded text-orange-600 focus:ring-orange-500"
              />
              <span>{device}</span>
            </label>
          ))}
        </div>
      </div>
    </div>
  );
}