import React, { useState } from 'react';
import { Radio, Tv, Clock, DollarSign, Calendar, ChevronDown, ChevronUp, MapPin, Users, TrendingUp, X } from 'lucide-react';

interface TimeSlot {
  start: string;
  end: string;
  viewership: number;
  price: number;
}

interface Station {
  name: string;
  slot_type: string;
  description: string;
  country: string;
  city: string;
  timeSlots: {
    morning: TimeSlot;
    afternoon: TimeSlot;
    evening: TimeSlot;
    night: TimeSlot;
  };
  demographics: {
    ageGroups: { range: string; percentage: number }[];
    gender: { male: number; female: number };
  };
}

interface CountryStations {
  [key: string]: Station[];
}

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  station: Station;
  timeSlot: string;
  onSubmit: (bookingData: { date: string; time: string }) => void;
}

function BookingModal({ isOpen, onClose, station, timeSlot, onSubmit }: BookingModalProps) {
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({ date, time });
  };

  const slot = station.timeSlots[timeSlot as keyof typeof station.timeSlots];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
        <div className="fixed inset-0 transition-opacity" aria-hidden="true">
          <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
        </div>

        <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
          <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
            <div className="sm:flex sm:items-start">
              <div className="mt-3 text-center sm:mt-0 sm:text-left w-full">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg leading-6 font-medium text-gray-900">
                    Book Advertising Slot
                  </h3>
                  <button
                    onClick={onClose}
                    className="text-gray-400 hover:text-gray-500"
                  >
                    <X className="h-6 w-6" />
                  </button>
                </div>

                <div className="mt-4">
                  <div className="bg-gray-50 p-4 rounded-lg mb-4">
                    <h4 className="font-medium text-gray-900">{station.name}</h4>
                    <p className="text-sm text-gray-600">{station.slot_type}</p>
                    <p className="text-sm text-gray-600">
                      Time Slot: {timeSlot} ({slot.start} - {slot.end})
                    </p>
                    <p className="text-sm font-medium text-gray-900 mt-2">
                      Price: ${slot.price}
                    </p>
                  </div>

                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                      <label htmlFor="date" className="block text-sm font-medium text-gray-700">
                        Select Date
                      </label>
                      <input
                        type="date"
                        id="date"
                        required
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        min={new Date().toISOString().split('T')[0]}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                      />
                    </div>

                    <div>
                      <label htmlFor="time" className="block text-sm font-medium text-gray-700">
                        Select Time
                      </label>
                      <input
                        type="time"
                        id="time"
                        required
                        value={time}
                        onChange={(e) => setTime(e.target.value)}
                        min={slot.start}
                        max={slot.end}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                      />
                      <p className="mt-1 text-sm text-gray-500">
                        Available between {slot.start} - {slot.end}
                      </p>
                    </div>

                    <div className="mt-5 sm:mt-4 sm:flex sm:flex-row-reverse">
                      <button
                        type="submit"
                        className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm"
                      >
                        Book Now
                      </button>
                      <button
                        type="button"
                        onClick={onClose}
                        className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:w-auto sm:text-sm"
                      >
                        Cancel
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function MediaInventory() {
  const [expandedCountry, setExpandedCountry] = useState<string | null>(null);
  const [expandedStation, setExpandedStation] = useState<string | null>(null);
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [selectedStation, setSelectedStation] = useState<Station | null>(null);
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string>('');

  const stations: Station[] = [
    // Nigeria
    {
      name: 'NTA Network',
      slot_type: '60-sec TV ad',
      description: 'National television network reaching all 36 states of Nigeria.',
      country: 'Nigeria',
      city: 'Lagos',
      timeSlots: {
        morning: { start: '06:00', end: '10:00', viewership: 2500000, price: 800 },
        afternoon: { start: '12:00', end: '16:00', viewership: 1500000, price: 600 },
        evening: { start: '18:00', end: '22:00', viewership: 5000000, price: 1200 },
        night: { start: '22:00', end: '00:00', viewership: 1000000, price: 400 }
      },
      demographics: {
        ageGroups: [
          { range: '18-24', percentage: 20 },
          { range: '25-34', percentage: 35 },
          { range: '35-44', percentage: 25 },
          { range: '45+', percentage: 20 }
        ],
        gender: { male: 48, female: 52 }
      }
    },
    {
      name: 'Channels TV',
      slot_type: '30-sec TV ad',
      description: 'Leading 24-hour news channel in Nigeria.',
      country: 'Nigeria',
      city: 'Lagos',
      timeSlots: {
        morning: { start: '07:00', end: '10:00', viewership: 1800000, price: 600 },
        afternoon: { start: '12:00', end: '15:00', viewership: 1200000, price: 450 },
        evening: { start: '19:00', end: '23:00', viewership: 3500000, price: 900 },
        night: { start: '23:00', end: '02:00', viewership: 800000, price: 300 }
      },
      demographics: {
        ageGroups: [
          { range: '18-24', percentage: 15 },
          { range: '25-34', percentage: 40 },
          { range: '35-44', percentage: 30 },
          { range: '45+', percentage: 15 }
        ],
        gender: { male: 55, female: 45 }
      }
    },
    // Kenya
    {
      name: 'Citizen TV',
      slot_type: '60-sec TV ad',
      description: 'Kenya\'s most watched television station.',
      country: 'Kenya',
      city: 'Nairobi',
      timeSlots: {
        morning: { start: '06:00', end: '09:00', viewership: 1500000, price: 600 },
        afternoon: { start: '12:00', end: '15:00', viewership: 1000000, price: 400 },
        evening: { start: '19:00', end: '22:00', viewership: 3000000, price: 900 },
        night: { start: '22:00', end: '00:00', viewership: 700000, price: 300 }
      },
      demographics: {
        ageGroups: [
          { range: '18-24', percentage: 25 },
          { range: '25-34', percentage: 35 },
          { range: '35-44', percentage: 25 },
          { range: '45+', percentage: 15 }
        ],
        gender: { male: 49, female: 51 }
      }
    },
    {
      name: 'Classic 105 FM',
      slot_type: '30-sec Radio ad',
      description: 'Popular urban radio station in Kenya.',
      country: 'Kenya',
      city: 'Nairobi',
      timeSlots: {
        morning: { start: '06:00', end: '10:00', viewership: 800000, price: 300 },
        afternoon: { start: '12:00', end: '15:00', viewership: 500000, price: 200 },
        evening: { start: '17:00', end: '20:00', viewership: 900000, price: 400 },
        night: { start: '20:00', end: '23:00', viewership: 300000, price: 150 }
      },
      demographics: {
        ageGroups: [
          { range: '18-24', percentage: 30 },
          { range: '25-34', percentage: 40 },
          { range: '35-44', percentage: 20 },
          { range: '45+', percentage: 10 }
        ],
        gender: { male: 45, female: 55 }
      }
    },
    // South Africa
    {
      name: 'SABC 1',
      slot_type: '60-sec TV ad',
      description: 'South Africa\'s largest television channel.',
      country: 'South Africa',
      city: 'Johannesburg',
      timeSlots: {
        morning: { start: '06:00', end: '09:00', viewership: 2000000, price: 700 },
        afternoon: { start: '12:00', end: '15:00', viewership: 1500000, price: 500 },
        evening: { start: '18:00', end: '22:00', viewership: 4000000, price: 1100 },
        night: { start: '22:00', end: '00:00', viewership: 900000, price: 350 }
      },
      demographics: {
        ageGroups: [
          { range: '18-24', percentage: 22 },
          { range: '25-34', percentage: 33 },
          { range: '35-44', percentage: 28 },
          { range: '45+', percentage: 17 }
        ],
        gender: { male: 47, female: 53 }
      }
    },
    {
      name: '5FM',
      slot_type: '30-sec Radio ad',
      description: 'National youth radio station in South Africa.',
      country: 'South Africa',
      city: 'Johannesburg',
      timeSlots: {
        morning: { start: '06:00', end: '10:00', viewership: 1200000, price: 400 },
        afternoon: { start: '12:00', end: '15:00', viewership: 800000, price: 300 },
        evening: { start: '16:00', end: '19:00', viewership: 1500000, price: 500 },
        night: { start: '19:00', end: '22:00', viewership: 600000, price: 250 }
      },
      demographics: {
        ageGroups: [
          { range: '18-24', percentage: 40 },
          { range: '25-34', percentage: 35 },
          { range: '35-44', percentage: 15 },
          { range: '45+', percentage: 10 }
        ],
        gender: { male: 52, female: 48 }
      }
    },
    // Ghana
    {
      name: 'TV3',
      slot_type: '60-sec TV ad',
      description: 'Ghana\'s leading free-to-air television channel.',
      country: 'Ghana',
      city: 'Accra',
      timeSlots: {
        morning: { start: '06:00', end: '09:00', viewership: 1200000, price: 500 },
        afternoon: { start: '12:00', end: '15:00', viewership: 800000, price: 350 },
        evening: { start: '19:00', end: '22:00', viewership: 2500000, price: 800 },
        night: { start: '22:00', end: '00:00', viewership: 500000, price: 250 }
      },
      demographics: {
        ageGroups: [
          { range: '18-24', percentage: 25 },
          { range: '25-34', percentage: 35 },
          { range: '35-44', percentage: 25 },
          { range: '45+', percentage: 15 }
        ],
        gender: { male: 51, female: 49 }
      }
    },
    {
      name: 'Joy FM',
      slot_type: '30-sec Radio ad',
      description: 'Premier English-language radio station in Ghana.',
      country: 'Ghana',
      city: 'Accra',
      timeSlots: {
        morning: { start: '05:00', end: '10:00', viewership: 900000, price: 350 },
        afternoon: { start: '12:00', end: '15:00', viewership: 600000, price: 250 },
        evening: { start: '17:00', end: '20:00', viewership: 1000000, price: 400 },
        night: { start: '20:00', end: '23:00', viewership: 400000, price: 200 }
      },
      demographics: {
        ageGroups: [
          { range: '18-24', percentage: 20 },
          { range: '25-34', percentage: 40 },
          { range: '35-44', percentage: 25 },
          { range: '45+', percentage: 15 }
        ],
        gender: { male: 54, female: 46 }
      }
    }
  ];

  const stationsByCountry: CountryStations = stations.reduce((acc, station) => {
    if (!acc[station.country]) {
      acc[station.country] = [];
    }
    acc[station.country].push(station);
    return acc;
  }, {} as CountryStations);

  const handleBookSlot = (station: Station, timeSlot: string) => {
    setSelectedStation(station);
    setSelectedTimeSlot(timeSlot);
    setIsBookingModalOpen(true);
  };

  const handleBookingSubmit = (bookingData: { date: string; time: string }) => {
    alert(`Booking submitted for ${selectedStation?.name}`);
    setIsBookingModalOpen(false);
  };

  const toggleCountry = (country: string) => {
    setExpandedCountry(expandedCountry === country ? null : country);
  };

  const toggleStation = (stationName: string) => {
    setExpandedStation(expandedStation === stationName ? null : stationName);
  };

  const formatNumber = (num: number): string => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    }
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  };

  const getTimeSlotClass = (viewership: number, maxViewership: number): string => {
    const ratio = viewership / maxViewership;
    if (ratio >= 0.8) return 'bg-green-100 text-green-800 border-green-200';
    if (ratio >= 0.5) return 'bg-yellow-100 text-yellow-800 border-yellow-200';
    return 'bg-gray-100 text-gray-800 border-gray-200';
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-900">Media Inventory</h1>
          <p className="mt-2 text-lg text-gray-600">
            Browse available advertising slots across Africa
          </p>
        </div>

        <div className="mt-12 space-y-6">
          {Object.entries(stationsByCountry).map(([country, countryStations]) => (
            <div key={country} className="bg-white rounded-lg shadow-md overflow-hidden">
              <button
                onClick={() => toggleCountry(country)}
                className="w-full px-6 py-4 flex items-center justify-between bg-gray-50 hover:bg-gray-100 transition-colors"
              >
                <div className="flex items-center space-x-3">
                  <MapPin className="h-5 w-5 text-orange-600" />
                  <h2 className="text-xl font-semibold text-gray-900">{country}</h2>
                  <span className="text-sm text-gray-500">
                    ({countryStations.length} stations)
                  </span>
                </div>
                {expandedCountry === country ? (
                  <ChevronUp className="h-5 w-5 text-gray-400" />
                ) : (
                  <ChevronDown className="h-5 w-5 text-gray-400" />
                )}
              </button>

              {expandedCountry === country && (
                <div className="p-6 space-y-6">
                  {countryStations.map((station, index) => (
                    <div
                      key={index}
                      className="bg-white rounded-lg shadow-sm overflow-hidden border border-gray-200"
                    >
                      <button
                        onClick={() => toggleStation(station.name)}
                        className="w-full px-6 py-4 flex items-center justify-between hover:bg-gray-50"
                      >
                        <div className="flex items-center">
                          {station.slot_type.includes('TV') ? (
                            <Tv className="h-6 w-6 text-orange-600" />
                          ) : (
                            <Radio className="h-6 w-6 text-orange-600" />
                          )}
                          <div className="ml-4">
                            <h3 className="text-lg font-semibold text-gray-900">{station.name}</h3>
                            <div className="flex items-center text-sm text-gray-500">
                              <MapPin className="h-4 w-4 mr-1" />
                              {station.city}
                            </div>
                          </div>
                        </div>
                        {expandedStation === station.name ? (
                          <ChevronUp className="h-5 w-5 text-gray-400" />
                        ) : (
                          <ChevronDown className="h-5 w-5 text-gray-400" />
                        )}
                      </button>

                      {expandedStation === station.name && (
                        <div className="px-6 pb-6">
                          <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                              <h4 className="text-sm font-medium text-gray-900 mb-4">Time Slots & Viewership</h4>
                              <div className="space-y-4">
                                {Object.entries(station.timeSlots).map(([slot, data]) => {
                                  const maxViewership = Math.max(
                                    ...Object.values(station.timeSlots).map(s => s.viewership)
                                  );
                                  return (
                                    <div
                                      key={slot}
                                      className={`p-4 rounded-lg border ${
                                        getTimeSlotClass(data.viewership, maxViewership)
                                      }`}
                                    >
                                      <div className="flex justify-between items-center">
                                        <div>
                                          <h5 className="font-medium capitalize">{slot}</h5>
                                          <p className="text-sm">
                                            {data.start} - {data.end}
                                          </p>
                                        </div>
                                        <div className="text-right">
                                          <div className="flex items-center">
                                            <Users className="h-4 w-4 mr-1" />
                                            <span>{formatNumber(data.viewership)}</span>
                                          </div>
                                          <p className="text-sm font-medium">
                                            ${data.price}
                                          </p>
                                        </div>
                                      </div>
                                      <button
                                        onClick={() => handleBookSlot(station, slot)}
                                        className="mt-2 w-full px-3 py-1 text-sm bg-white rounded border border-current hover:bg-gray-50"
                                      >
                                        Book Slot
                                      </button>
                                    </div>
                                  );
                                })}
                              </div>
                            </div>

                            <div>
                              <h4 className="text-sm font-medium text-gray-900 mb-4">Audience Demographics</h4>
                              <div className="space-y-6">
                                <div>
                                  <h5 className="text-sm font-medium text-gray-700 mb-2">Age Distribution</h5>
                                  <div className="space-y-2">
                                    {station.demographics.ageGroups.map((group) => (
                                      <div key={group.range} className="flex items-center">
                                        <span className="w-16 text-sm text-gray-500">{group.range}</span>
                                        <div className="flex-1 mx-2">
                                          <div className="h-2 bg-gray-200 rounded-full">
                                            <div
                                              className="h-2 bg-orange-600 rounded-full"
                                              style={{ width: `${group.percentage}%` }}
                                            />
                                          </div>
                                        </div>
                                        <span className="w-12 text-sm text-gray-500">{group.percentage}%</span>
                                      </div>
                                    ))}
                                  </div>
                                </div>

                                <div>
                                  <h5 className="text-sm font-medium text-gray-700 mb-2">Gender Distribution</h5>
                                  <div className="flex h-4 rounded-full overflow-hidden">
                                    <div
                                      className="bg-blue-500"
                                      style={{ width: `${station.demographics.gender.male}%` }}
                                    />
                                    <div
                                      className="bg-pink-500"
                                      style={{ width: `${station.demographics.gender.female}%` }}
                                    />
                                  </div>
                                  <div className="mt-2 flex justify-between text-sm">
                                    <span className="text-blue-500">Male {station.demographics.gender.male}%</span>
                                    <span className="text-pink-500">Female {station.demographics.gender.female}%</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
      
      {selectedStation && (
        <BookingModal
          isOpen={isBookingModalOpen}
          onClose={() => setIsBookingModalOpen(false)}
          station={selectedStation}
          timeSlot={selectedTimeSlot}
          onSubmit={handleBookingSubmit}
        />
      )}
    </div>
  );
}