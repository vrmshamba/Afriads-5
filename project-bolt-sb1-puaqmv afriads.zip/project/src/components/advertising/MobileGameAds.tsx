import React, { useState } from 'react';
import { Smartphone, Gamepad2, Users, Target, BarChart3, Upload } from 'lucide-react';

interface Game {
  id: string;
  name: string;
  category: string;
  dailyUsers: number;
  adFormats: string[];
  minBudget: number;
  targetAudience: string;
  engagementRate: number;
}

export default function MobileGameAds() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string>('');
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    callToAction: '',
    targetUrl: '',
    budget: '',
    selectedGames: [] as string[],
    adFormat: ''
  });

  const games: Game[] = [
    {
      id: '1',
      name: 'African Legends',
      category: 'Adventure',
      dailyUsers: 500000,
      adFormats: ['Interstitial', 'Rewarded', 'Banner'],
      minBudget: 100,
      targetAudience: '18-34 years',
      engagementRate: 15.5
    },
    {
      id: '2',
      name: 'Safari Rush',
      category: 'Racing',
      dailyUsers: 300000,
      adFormats: ['Rewarded', 'Banner'],
      minBudget: 75,
      targetAudience: '16-28 years',
      engagementRate: 12.8
    },
    {
      id: '3',
      name: 'City Builder Africa',
      category: 'Simulation',
      dailyUsers: 400000,
      adFormats: ['Interstitial', 'Banner'],
      minBudget: 90,
      targetAudience: '22-45 years',
      engagementRate: 18.2
    }
  ];

  const adFormats = [
    { id: 'interstitial', name: 'Interstitial', description: 'Full-screen ads between game levels' },
    { id: 'rewarded', name: 'Rewarded', description: 'Optional ads that reward players with in-game items' },
    { id: 'banner', name: 'Banner', description: 'Static or animated banners during gameplay' }
  ];

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleGameToggle = (gameId: string) => {
    setFormData(prev => ({
      ...prev,
      selectedGames: prev.selectedGames.includes(gameId)
        ? prev.selectedGames.filter(id => id !== gameId)
        : [...prev.selectedGames, gameId]
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Form submitted:', { ...formData, file: selectedFile });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold text-gray-900">Mobile Game Advertising</h2>
        <p className="mt-4 text-lg text-gray-600">
          Reach engaged gamers across popular African mobile games
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <div>
          <h3 className="text-xl font-semibold text-gray-900 mb-6">Create Your Ad</h3>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Ad Format
              </label>
              <select
                name="adFormat"
                value={formData.adFormat}
                onChange={handleInputChange}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-orange-500 focus:border-orange-500 sm:text-sm"
              >
                <option value="">Select an ad format</option>
                {adFormats.map(format => (
                  <option key={format.id} value={format.id}>
                    {format.name}
                  </option>
                ))}
              </select>
              {formData.adFormat && (
                <p className="mt-2 text-sm text-gray-500">
                  {adFormats.find(f => f.id === formData.adFormat)?.description}
                </p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Media Upload
              </label>
              <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-lg">
                {previewUrl ? (
                  <div className="space-y-1 text-center">
                    <img src={previewUrl} alt="Preview" className="mx-auto h-32 w-auto" />
                    <div className="flex text-sm text-gray-600">
                      <label className="relative cursor-pointer bg-white rounded-md font-medium text-orange-600 hover:text-orange-500">
                        <span>Change file</span>
                        <input
                          type="file"
                          className="sr-only"
                          onChange={handleFileChange}
                          accept="image/*,video/*"
                        />
                      </label>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-1 text-center">
                    <Upload className="mx-auto h-12 w-12 text-gray-400" />
                    <div className="flex text-sm text-gray-600">
                      <label className="relative cursor-pointer bg-white rounded-md font-medium text-orange-600 hover:text-orange-500">
                        <span>Upload a file</span>
                        <input
                          type="file"
                          className="sr-only"
                          onChange={handleFileChange}
                          accept="image/*,video/*"
                        />
                      </label>
                    </div>
                    <p className="text-xs text-gray-500">PNG, JPG, GIF, MP4 up to 50MB</p>
                  </div>
                )}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Ad Title
              </label>
              <input
                type="text"
                name="title"
                value={formData.title}
                onChange={handleInputChange}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-orange-500 focus:border-orange-500 sm:text-sm"
                placeholder="Enter your ad title"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Description
              </label>
              <textarea
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                rows={4}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-orange-500 focus:border-orange-500 sm:text-sm"
                placeholder="Enter your ad description"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Call to Action
              </label>
              <input
                type="text"
                name="callToAction"
                value={formData.callToAction}
                onChange={handleInputChange}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-orange-500 focus:border-orange-500 sm:text-sm"
                placeholder="e.g., Play Now, Download"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Target URL
              </label>
              <input
                type="url"
                name="targetUrl"
                value={formData.targetUrl}
                onChange={handleInputChange}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-orange-500 focus:border-orange-500 sm:text-sm"
                placeholder="https://example.com"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Budget (USD)
              </label>
              <input
                type="number"
                name="budget"
                value={formData.budget}
                onChange={handleInputChange}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-orange-500 focus:border-orange-500 sm:text-sm"
                placeholder="Enter your budget"
              />
            </div>

            <button
              type="submit"
              className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-orange-600 hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500"
            >
              Create Campaign
            </button>
          </form>
        </div>

        <div>
          <h3 className="text-xl font-semibold text-gray-900 mb-6">Available Games</h3>
          <div className="space-y-4">
            {games.map(game => (
              <div
                key={game.id}
                className="bg-white rounded-lg shadow-sm border border-gray-200 p-6"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Gamepad2 className="h-6 w-6 text-orange-600" />
                    <h4 className="ml-2 text-lg font-medium text-gray-900">{game.name}</h4>
                  </div>
                  <input
                    type="checkbox"
                    checked={formData.selectedGames.includes(game.id)}
                    onChange={() => handleGameToggle(game.id)}
                    className="h-4 w-4 text-orange-600 focus:ring-orange-500 border-gray-300 rounded"
                  />
                </div>

                <div className="mt-4 grid grid-cols-2 gap-4">
                  <div className="flex items-center text-sm text-gray-500">
                    <Users className="h-4 w-4 mr-1" />
                    {game.dailyUsers.toLocaleString()} daily users
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <Target className="h-4 w-4 mr-1" />
                    {game.targetAudience}
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <BarChart3 className="h-4 w-4 mr-1" />
                    {game.engagementRate}% engagement
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <Smartphone className="h-4 w-4 mr-1" />
                    {game.adFormats.join(', ')}
                  </div>
                </div>

                <div className="mt-4 text-sm text-gray-500">
                  Minimum budget: ${game.minBudget}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}