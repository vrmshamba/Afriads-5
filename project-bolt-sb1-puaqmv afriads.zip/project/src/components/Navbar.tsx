import React, { useState, useEffect } from 'react';
import { Menu, X, Globe2, BarChart3, PieChart } from 'lucide-react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { supabase } from '../lib/supabase';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('features');
  const [user, setUser] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const getUser = async () => {
      setIsLoading(true);
      try {
        const { data: { user }, error } = await supabase.auth.getUser();
        if (error) {
          // Handle auth session missing error silently - user is not logged in
          if (error.name === 'AuthSessionMissingError') {
            setUser(null);
            return;
          }
          console.error('Error fetching user in navbar:', error);
        }
        setUser(user);
      } catch (err) {
        console.error('Unexpected error in navbar auth:', err);
        setUser(null);
      } finally {
        setIsLoading(false);
      }
    };

    getUser();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  const scrollToSection = (sectionId: string) => {
    if (location.pathname !== '/') {
      navigate('/');
      setTimeout(() => {
        const element = document.getElementById(sectionId);
        if (element) {
          element.scrollIntoView({ behavior: 'smooth' });
          setActiveSection(sectionId);
          setIsOpen(false);
        }
      }, 100);
    } else {
      const element = document.getElementById(sectionId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
        setActiveSection(sectionId);
        setIsOpen(false);
      }
    }
  };

  const handleGetStarted = () => {
    navigate('/register');
  };

  const handleSignOut = async () => {
    try {
      setIsLoading(true);
      const { error } = await supabase.auth.signOut();
      if (error) {
        console.error('Sign out error:', error);
      }
      navigate('/');
    } catch (err) {
      console.error('Unexpected error during sign out:', err);
      navigate('/');
    } finally {
      setIsLoading(false);
    }
  };

  const navItems = [
    { id: 'features', label: 'Features' },
    { id: 'pricing', label: 'Pricing' },
    { id: 'about', label: 'About' },
    { id: 'faq', label: 'FAQ' },
    { id: 'contact', label: 'Contact' }
  ];

  return (
    <nav className="fixed w-full z-50 bg-orange-600 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center">
              <Globe2 className="h-8 w-8" />
              <span className="ml-2 text-xl font-bold">AfriAds</span>
            </Link>
          </div>
          
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`px-3 py-2 rounded-md transition-colors ${
                    activeSection === item.id ? 'bg-orange-700' : 'hover:bg-orange-500'
                  }`}
                >
                  {item.label}
                </button>
              ))}
              {isLoading ? (
                <div className="w-4 h-4 rounded-full border-2 border-white border-t-transparent animate-spin"></div>
              ) : user ? (
                <>
                  <Link
                    to="/dashboard"
                    className="text-white hover:text-orange-200 transition-colors"
                  >
                    Dashboard
                  </Link>
                  <Link
                    to="/media-inventory"
                    className="text-white hover:text-orange-200 transition-colors"
                  >
                    Browse Slots
                  </Link>
                  <Link
                    to="/media-planning"
                    className="flex items-center text-white hover:text-orange-200 transition-colors"
                  >
                    <BarChart3 className="h-4 w-4 mr-1" />
                    Media Planning
                  </Link>
                  <Link
                    to="/analytics"
                    className="flex items-center text-white hover:text-orange-200 transition-colors"
                  >
                    <PieChart className="h-4 w-4 mr-1" />
                    Analytics
                  </Link>
                  <button
                    onClick={handleSignOut}
                    className="text-white hover:text-orange-200 transition-colors"
                  >
                    Sign Out
                  </button>
                </>
              ) : (
                <>
                  <Link
                    to="/login"
                    className="text-white hover:text-orange-200 transition-colors"
                  >
                    Login
                  </Link>
                  <button 
                    onClick={handleGetStarted}
                    className="bg-white text-orange-600 px-4 py-2 rounded-md font-medium hover:bg-orange-100 transition-colors"
                  >
                    Get Started
                  </button>
                </>
              )}
            </div>
          </div>
          
          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="p-2">
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden absolute w-full bg-orange-600 shadow-lg">
          <div className="px-2 pt-2 pb-3 space-y-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className={`block w-full text-left px-3 py-2 rounded-md ${
                  activeSection === item.id ? 'bg-orange-700' : 'hover:bg-orange-500'
                }`}
              >
                {item.label}
              </button>
            ))}
            {isLoading ? (
              <div className="flex justify-center py-2">
                <div className="w-4 h-4 rounded-full border-2 border-white border-t-transparent animate-spin"></div>
              </div>
            ) : user ? (
              <>
                <Link
                  to="/dashboard"
                  className="block w-full text-left px-3 py-2 rounded-md hover:bg-orange-500"
                >
                  Dashboard
                </Link>
                <Link
                  to="/media-inventory"
                  className="block w-full text-left px-3 py-2 rounded-md hover:bg-orange-500"
                >
                  Browse Slots
                </Link>
                <Link
                  to="/media-planning"
                  className="block w-full text-left px-3 py-2 rounded-md hover:bg-orange-500"
                >
                  Media Planning
                </Link>
                <Link
                  to="/analytics"
                  className="block w-full text-left px-3 py-2 rounded-md hover:bg-orange-500"
                >
                  Analytics
                </Link>
                <button
                  onClick={handleSignOut}
                  className="block w-full text-left px-3 py-2 rounded-md hover:bg-orange-500"
                >
                  Sign Out
                </button>
              </>
            ) : (
              <>
                <Link
                  to="/login"
                  className="block w-full text-left px-3 py-2 rounded-md hover:bg-orange-500"
                >
                  Login
                </Link>
                <button
                  onClick={handleGetStarted}
                  className="block w-full text-center bg-white text-orange-600 px-4 py-2 rounded-md font-medium hover:bg-orange-100 transition-colors"
                >
                  Get Started
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}