import React, { useState, useEffect } from 'react';
import { ArrowRight, MessageCircle, Smartphone, Radio } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const cityImages = [
  {
    url: 'https://images.unsplash.com/photo-1580825147092-ba453f859ef6?auto=format&fit=crop&q=80',
    city: 'Lagos, Nigeria',
    description: 'The bustling heart of West African commerce'
  },
  {
    url: 'https://images.unsplash.com/photo-1611348586804-61bf6c080437?auto=format&fit=crop&q=80',
    city: 'Nairobi, Kenya',
    description: 'East Africa\'s technology hub'
  },
  {
    url: 'https://images.unsplash.com/photo-1547471080-7cc2caa01a7e?auto=format&fit=crop&q=80',
    city: 'Accra, Ghana',
    description: 'A vibrant cultural capital'
  },
  {
    url: 'https://images.unsplash.com/photo-1577192716115-7230f05dab63?auto=format&fit=crop&q=80',
    city: 'Johannesburg, South Africa',
    description: 'The economic powerhouse of Africa'
  }
];

export default function Hero() {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [fadeOut, setFadeOut] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const interval = setInterval(() => {
      setFadeOut(true);
      setTimeout(() => {
        setCurrentImageIndex((prev) => (prev + 1) % cityImages.length);
        setFadeOut(false);
      }, 500);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const handleStartCampaign = () => {
    // Navigate to register page when button is clicked
    navigate('/register');
  };

  return (
    <div className="relative min-h-screen overflow-hidden bg-gradient-to-br from-orange-600 to-red-700">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <div 
          className={`absolute inset-0 bg-cover bg-center transition-opacity duration-500 ${
            fadeOut ? 'opacity-0' : 'opacity-60'
          }`}
          style={{ backgroundImage: `url('${cityImages[currentImageIndex].url}')` }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/50 to-transparent" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-32">
        <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
          <div className="text-center lg:text-left">
            <h1 className="text-4xl tracking-tight font-extrabold text-white sm:text-5xl md:text-6xl">
              <span className="block mb-2">Transform Your Reach in</span>
              <span className="block text-yellow-400">African Markets</span>
            </h1>
            <p className="mt-6 text-xl text-gray-200 sm:max-w-xl">
              Connect with millions through targeted advertising on Telegram, mobile games, and broadcast media. 
              Tailored for African audiences, powered by local payment solutions.
            </p>
            
            <div className="mt-8 sm:flex sm:justify-center lg:justify-start">
              <button
                id="startCampaignBtn"
                onClick={handleStartCampaign}
                className="w-full sm:w-auto flex items-center justify-center px-8 py-4 border-2 border-white text-base font-medium rounded-lg text-white hover:bg-white hover:text-orange-600 transition-all duration-300 md:text-lg md:px-10"
              >
                Start Campaign
                <ArrowRight className="ml-2 h-5 w-5" />
              </button>
            </div>

            {/* City Info */}
            <div className="mt-8 text-left">
              <h2 className="text-white text-xl font-semibold">
                {cityImages[currentImageIndex].city}
              </h2>
              <p className="text-gray-300">
                {cityImages[currentImageIndex].description}
              </p>
            </div>
          </div>

          <div className="mt-12 lg:mt-0">
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-3 lg:gap-8">
              {[
                {
                  icon: MessageCircle,
                  title: 'Telegram Ads',
                  description: 'Reach active African audiences',
                  route: '/advertising/telegram'
                },
                {
                  icon: Smartphone,
                  title: 'Mobile Gaming',
                  description: 'Target gaming communities',
                  route: '/advertising/mobile-games'
                },
                {
                  icon: Radio,
                  title: 'Broadcast Media',
                  description: 'TV & Radio advertising',
                  route: '/media-inventory'
                }
              ].map((platform, index) => (
                <div
                  key={index}
                  onClick={() => navigate(platform.route)}
                  className="relative group cursor-pointer"
                >
                  <div className="absolute -inset-0.5 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-lg blur opacity-25 group-hover:opacity-75 transition duration-300" />
                  <div className="relative bg-black/40 backdrop-blur-sm p-6 rounded-lg border border-white/10 hover:border-white/20 transition-all duration-300">
                    <platform.icon className="h-8 w-8 text-yellow-400" />
                    <h3 className="mt-4 text-lg font-medium text-white">
                      {platform.title}
                    </h3>
                    <p className="mt-2 text-sm text-gray-300">
                      {platform.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}