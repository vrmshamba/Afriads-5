import axios from 'axios';
import { Ad } from '../types/ad';

const TELEGRAM_API_BASE = 'https://api.telegram.org/bot';
const BOT_TOKEN = process.env.VITE_TELEGRAM_BOT_TOKEN;

export class TelegramService {
  private static async request(method: string, data: any = {}) {
    try {
      const response = await axios.post(
        `${TELEGRAM_API_BASE}${BOT_TOKEN}/${method}`,
        data
      );
      return response.data;
    } catch (error) {
      console.error('Telegram API error:', error);
      throw error;
    }
  }

  static async deployAd(ad: Ad) {
    const messageText = `
🌟 *${ad.content.title}*

${ad.content.description}

${ad.content.callToAction}: ${ad.content.landingUrl}
    `.trim();

    const channels = await this.getTargetChannels(ad.targeting);
    const results = [];

    for (const channel of channels) {
      if (ad.content.mediaUrl) {
        if (ad.format === 'image') {
          results.push(await this.request('sendPhoto', {
            chat_id: channel,
            photo: ad.content.mediaUrl,
            caption: messageText,
            parse_mode: 'Markdown'
          }));
        } else if (ad.format === 'video') {
          results.push(await this.request('sendVideo', {
            chat_id: channel,
            video: ad.content.mediaUrl,
            caption: messageText,
            parse_mode: 'Markdown'
          }));
        }
      } else {
        results.push(await this.request('sendMessage', {
          chat_id: channel,
          text: messageText,
          parse_mode: 'Markdown'
        }));
      }
    }

    return results;
  }

  private static async getTargetChannels(targeting: Ad['targeting']) {
    // Simulate fetching relevant channels based on targeting criteria
    return ['@afriads_test', '@afriads_demo'];
  }

  static async getAdStats(messageIds: string[]) {
    // Simulate fetching message statistics
    return {
      views: Math.floor(Math.random() * 10000),
      clicks: Math.floor(Math.random() * 1000),
      engagement: Math.random() * 0.1
    };
  }
}