/*
  # Create stations table for media inventory

  1. New Tables
    - `stations` table
      - `id` (uuid, primary key)
      - `name` (text, station name)
      - `slot_type` (text, type of advertising slot)
      - `price` (integer, cost in USD)
      - `created_at` (timestamp)
      - `available_slots` (integer, number of available slots)
      - `description` (text, station description)
      - `peak_hours` (boolean, whether slot is during peak hours)

  2. Security
    - Enable RLS on stations table
    - Add policies for authenticated users to read stations data
*/

CREATE TABLE IF NOT EXISTS stations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slot_type text NOT NULL,
  price integer NOT NULL CHECK (price >= 0),
  created_at timestamptz DEFAULT now(),
  available_slots integer NOT NULL DEFAULT 0 CHECK (available_slots >= 0),
  description text,
  peak_hours boolean DEFAULT false
);

-- Enable Row Level Security
ALTER TABLE stations ENABLE ROW LEVEL SECURITY;

-- Create policy for reading stations data
CREATE POLICY "Anyone can view stations" 
  ON stations 
  FOR SELECT 
  USING (true);

-- Insert sample data
INSERT INTO stations (name, slot_type, price, available_slots, description, peak_hours)
VALUES 
  ('Channel 5 TV', '30-sec TV ad', 500, 10, 'Prime time television advertising slot on Channel 5, reaching millions of viewers across major cities.', true),
  ('Metro FM Radio', '60-sec Radio spot', 300, 15, 'Drive-time radio advertising slot on Metro FM, the most popular urban radio station.', true);