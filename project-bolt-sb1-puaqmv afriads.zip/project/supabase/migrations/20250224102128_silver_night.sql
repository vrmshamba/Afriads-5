/*
  # Add phone number to profiles table

  1. Changes
    - Add phone_number column to profiles table
    - Add validation to ensure phone numbers are in a valid format

  2. Notes
    - Phone numbers will be stored as text to support international formats
    - No data loss as this is an additive change
*/

DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' 
    AND column_name = 'phone_number'
  ) THEN
    ALTER TABLE profiles ADD COLUMN phone_number text;
    
    -- Add a check constraint to ensure phone numbers are in a valid format
    ALTER TABLE profiles ADD CONSTRAINT phone_number_format 
      CHECK (
        phone_number IS NULL OR 
        phone_number ~ '^\+?[1-9]\d{1,14}$'
      );
  END IF;
END $$;